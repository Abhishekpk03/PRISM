"""
build_solution_pdf.py
Renders SOLUTION_DESCRIPTION.md -> PRISM_Solution_Description.pdf

Same discipline as the problem-statement builder: the markdown is the only
source of truth, so the PDF cannot drift from it.

Elements
  [[FLOW]]        -> architecture diagram drawn as vectors
  ### C<n> · ..   -> component card (accent rule + labelled fields)
  ### N<n> · ..   -> novelty card
  tables, bullets, numbered lists, block quotes

Run:  python3 build_solution_pdf.py
"""

import os
import re

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (KeepTogether, BaseDocTemplate, Flowable, Frame, NextPageTemplate,
                                PageBreak, PageTemplate, Paragraph, Spacer, Table,
                                TableStyle)

BASE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(BASE, "SOLUTION_DESCRIPTION.md")
OUT = os.path.join(BASE, "PRISM_Solution_Description.pdf")
FDIR = "/usr/share/fonts/truetype/dejavu"

pdfmetrics.registerFont(TTFont("DJV", f"{FDIR}/DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DJV-B", f"{FDIR}/DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("DJV-M", f"{FDIR}/DejaVuSansMono.ttf"))
pdfmetrics.registerFont(TTFont("DJV-S", f"{FDIR}/DejaVuSerif.ttf"))
pdfmetrics.registerFont(TTFont("DJV-SB", f"{FDIR}/DejaVuSerif-Bold.ttf"))
pdfmetrics.registerFontFamily("DJV", normal="DJV", bold="DJV-B",
                              italic="DJV-S", boldItalic="DJV-SB")

NAVY = colors.HexColor("#16233A")
NAVY_L = colors.HexColor("#2A3D5C")
CYAN = colors.HexColor("#1D6FA5")
CYAN_L = colors.HexColor("#E7F0F7")
AMBER = colors.HexColor("#B8730A")
AMBER_L = colors.HexColor("#FBF3E4")
INK = colors.HexColor("#1A1A1A")
BODY = colors.HexColor("#232A33")
MUTE = colors.HexColor("#5B6B7C")
RULE = colors.HexColor("#D5DCE4")
WASH = colors.HexColor("#F4F6F9")
RED = colors.HexColor("#A3291F")
GREEN = colors.HexColor("#1C6B45")

PW, PH = A4
ML = MR = 54
MT, MB = 62, 56
CW = PW - ML - MR

S = {}


def mk(name, **kw):
    base = dict(name=name, fontName="DJV", fontSize=9.3, leading=14.0,
                textColor=BODY, alignment=TA_LEFT, spaceBefore=0, spaceAfter=0,
                allowWidows=0, allowOrphans=0)
    base.update(kw)
    S[name] = ParagraphStyle(**base)
    return S[name]


mk("h2", fontName="DJV-B", fontSize=13.0, leading=16.8, textColor=NAVY,
   spaceBefore=16, spaceAfter=7, keepWithNext=1)
mk("h3", fontName="DJV-B", fontSize=10.2, leading=13.8, textColor=CYAN,
   spaceBefore=10, spaceAfter=4, keepWithNext=1)
mk("body", spaceAfter=6.5)
mk("bullet", leftIndent=13, bulletIndent=2, spaceAfter=3.5)
mk("num", leftIndent=17, bulletIndent=2, spaceAfter=3.5)
mk("quote", fontName="DJV-S", fontSize=10.8, leading=16.4, textColor=NAVY,
   leftIndent=13, rightIndent=6)
mk("tcell", fontSize=8.4, leading=11.6)
mk("thead", fontName="DJV-B", fontSize=8.1, leading=11.0, textColor=colors.white)
mk("kicker", fontName="DJV-B", fontSize=8.3, leading=11, textColor=CYAN)
mk("small", fontSize=8.2, leading=12.0, textColor=MUTE)
mk("cardtitle", fontName="DJV-B", fontSize=10.2, leading=13.6, textColor=NAVY)
mk("field", spaceAfter=2.6)


def inline(t):
    t = t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"(?<!\*)\*([^*]+?)\*(?!\*)", r"<i>\1</i>", t)
    t = re.sub(r"`(.+?)`", r'<font name="DJV-M" size="8.3">\1</font>', t)
    return t


def para(text, style="body"):
    return Paragraph(inline(text), S[style])


# ------------------------------------------------------------------- tables --
def fit_widths(header, rows, pad=11.0, size_h=8.1, size_c=8.4):
    """Column widths that never break a single word.

    Proportional to content, then floors enforced using EXACT string widths from
    the font metrics, then any remaining deficit is taken only from columns that
    still have slack. A naive floor-then-normalise pass re-shrinks the columns it
    just protected, which is how 'Determinism' got split mid-word.
    """
    ncols = len(header)
    floors, wants = [], []
    for c in range(ncols):
        cells = [header[c]] + [r[c] for r in rows]
        longest_word = max((w for cell in cells for w in str(cell).split()), key=len,
                           default="mm")
        fw = pdfmetrics.stringWidth(longest_word, "DJV-B", size_h)
        floors.append(fw + pad + 2)
        widest = max((pdfmetrics.stringWidth(str(x), "DJV", size_c) for x in cells),
                     default=40.0)
        wants.append(max(widest + pad, floors[-1]))

    # 1. proportional first, 2. lift any column to its floor, 3. take the excess
    #    only from columns that still have slack. Iterate until stable -- doing the
    #    floor BEFORE the proportional split silently un-does it on renormalisation.
    tot = sum(wants)
    widths = [CW * w / tot for w in wants]

    for _ in range(80):
        for k in range(ncols):
            if widths[k] < floors[k] - 1e-6:
                widths[k] = floors[k]
        excess = sum(widths) - CW
        if excess <= 0.2:
            break
        slack = [max(0.0, widths[k] - floors[k]) for k in range(ncols)]
        tot_slack = sum(slack)
        if tot_slack <= 0.2:
            break
        widths = [widths[k] - excess * slack[k] / tot_slack for k in range(ncols)]

    if sum(widths) < CW - 0.2:                 # grow to fill the measure
        short = CW - sum(widths)
        widths = [widths[k] + short * wants[k] / tot for k in range(ncols)]
    return widths


def mk_table(header, rows, widths=None, first_col_bold=False):
    ncols = len(header)
    if widths is None:
        widths = fit_widths(header, rows)

    data = [[Paragraph(inline(c), S["thead"]) for c in header]]
    for r in rows:
        data.append([Paragraph(inline(c), S["tcell"]) for c in r])

    t = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    st = [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 4.6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4.6),
        ("LEFTPADDING", (0, 0), (-1, -1), 5.5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5.5),
        ("LINEBELOW", (0, 0), (-1, -1), 0.35, RULE),
        ("LINEBELOW", (0, 0), (-1, 0), 0.8, NAVY),
    ]
    for i in range(1, len(data)):
        if i % 2 == 0:
            st.append(("BACKGROUND", (0, i), (-1, i), WASH))
    t.setStyle(TableStyle(st))
    return t


# ---------------------------------------------------------------- callouts --
class Rule(Flowable):
    def __init__(self, w, thickness=0.8, col=RULE, pad=5):
        Flowable.__init__(self)
        self.w, self.t, self.c, self.pad = w, thickness, col, pad
        self.height = thickness + pad * 2

    def draw(self):
        self.canv.setStrokeColor(self.c)
        self.canv.setLineWidth(self.t)
        self.canv.line(0, self.pad, self.w, self.pad)


class Flow(Flowable):
    """The architecture, drawn as vectors so it stays crisp at any zoom."""

    STEPS = [("1", "STANDING", "records", CYAN),
             ("2", "CONDITION", "satellite", colors.HexColor("#5B4B8A")),
             ("3", "MECHANISM", "posterior", AMBER),
             ("4", "VOIDS", "geometry", CYAN),
             ("5", "OCCUPANCY", "people", GREEN),
             ("6", "SURVIVAL", "clock", GREEN),
             ("7", "TASKING", "lives/hour", RED)]

    def __init__(self, width, height=64):
        Flowable.__init__(self)
        self.width, self.height = width, height

    def draw(self):
        c = self.canv
        n = len(self.STEPS)
        gap = 5.0
        bw = (self.width - gap * (n - 1)) / n
        bh = 46
        y = 8
        c.setFillColor(MUTE)
        c.setFont("DJV-B", 6.4)
        c.drawString(0, y + bh + 9, "RECORDS  ·  SATELLITE  ·  SENSOR   →   SEVEN STAGES   →   ONE PAGE")
        for i, (num, name, sub, col) in enumerate(self.STEPS):
            x = i * (bw + gap)
            c.setFillColor(colors.HexColor("#FBFCFD"))
            c.setStrokeColor(col)
            c.setLineWidth(1.0)
            c.roundRect(x, y, bw, bh, 3, stroke=1, fill=1)
            c.setFillColor(col)
            c.rect(x, y + bh - 3.2, bw, 3.2, stroke=0, fill=1)
            c.setFillColor(col)
            c.setFont("DJV-B", 6.0)
            c.drawString(x + 5, y + bh - 12, num)
            c.setFillColor(NAVY)
            c.setFont("DJV-B", 6.9)
            c.drawCentredString(x + bw / 2, y + 20, name)
            c.setFillColor(MUTE)
            c.setFont("DJV", 6.2)
            c.drawCentredString(x + bw / 2, y + 10, sub)
            if i < n - 1:
                c.setStrokeColor(colors.HexColor("#9AAAB8"))
                c.setLineWidth(1.0)
                x0 = x + bw + 0.6
                x1 = x + bw + gap - 0.6
                c.line(x0, y + bh / 2, x1, y + bh / 2)


def callout(fl, border=CYAN, bg=CYAN_L):
    t = Table([[fl]], colWidths=[CW], hAlign="LEFT")
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), bg),
        ("LINEBEFORE", (0, 0), (0, -1), 3.2, border),
        ("TOPPADDING", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("LEFTPADDING", (0, 0), (-1, -1), 13),
        ("RIGHTPADDING", (0, 0), (-1, -1), 13),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    return t


def card(cid, title, items):
    rows = [Paragraph(
        f"<font name='DJV-B' size='11' color='#1D6FA5'>{cid}</font>"
        f"&nbsp;&nbsp;{inline(title)}", S["cardtitle"])]
    for label, text in items:
        if label:
            rows.append(Paragraph(
                f"<b>{inline(label)}.</b> {inline(text)}", S["field"]))
        else:
            rows.append(Paragraph(inline(text), S["field"]))
    t = Table([[rows]], colWidths=[CW], hAlign="LEFT")
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.white),
        ("LINEBEFORE", (0, 0), (0, -1), 2.6, CYAN),
        ("BOX", (0, 0), (-1, -1), 0.4, RULE),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("LEFTPADDING", (0, 0), (-1, -1), 12),
        ("RIGHTPADDING", (0, 0), (-1, -1), 11),
    ]))
    return t


# ------------------------------------------------------------------- pages --
def cover_page(canv, doc):
    canv.saveState()
    band_h = 250
    canv.setFillColor(NAVY)
    canv.rect(0, PH - band_h, PW, band_h, stroke=0, fill=1)
    canv.setFillColor(CYAN)
    canv.rect(0, PH - band_h - 4, PW, 4, stroke=0, fill=1)

    canv.setFillColor(colors.HexColor("#6FB3DA"))
    canv.setFont("DJV-B", 8.6)
    canv.drawString(ML, PH - 62,
                    "INNOVEX 2026  ·  SEASON 02  ·  NSS IT WING  ·  NITTE UNIVERSITY")
    canv.setFillColor(colors.white)
    canv.setFont("DJV-B", 44)
    canv.drawString(ML - 2, PH - 126, "PRISM")
    canv.setFillColor(colors.HexColor("#CBD9E6"))
    canv.setFont("DJV", 15.5)
    canv.drawString(ML, PH - 156, "Solution Description")
    canv.setFillColor(colors.HexColor("#8FA3BC"))
    canv.setFont("DJV", 9.4)
    canv.drawString(ML, PH - 182, "Problem Statement 5  —  Project Abhedya")
    canv.drawString(ML, PH - 197, "Focus Area 03  —  Search & Rescue")
    canv.drawString(ML, PH - 212,
                    "Nine components · three novel solutions · accuracy defined before claimed")

    canv.setStrokeColor(colors.HexColor("#3C4F6E"))
    canv.setLineWidth(0.6)
    canv.line(ML, PH - 224, PW - MR, PH - 224)
    canv.setFillColor(colors.HexColor("#6E8099"))
    canv.setFont("DJV", 8)
    canv.drawString(ML, 34, "PRISM / Solution Description")
    canv.setFont("DJV-B", 8)
    canv.drawRightString(PW - MR, 34, "01")
    canv.restoreState()


def body_page(canv, doc):
    canv.saveState()
    canv.setStrokeColor(RULE)
    canv.setLineWidth(0.6)
    canv.line(ML, PH - 44, PW - MR, PH - 44)
    canv.setFillColor(MUTE)
    canv.setFont("DJV-B", 7.6)
    canv.drawString(ML, PH - 38, "PRISM  ·  SOLUTION DESCRIPTION")
    canv.setFont("DJV", 7.6)
    canv.drawRightString(PW - MR, PH - 38, "Focus Area 03 · Search & Rescue")
    canv.setStrokeColor(RULE)
    canv.line(ML, 40, PW - MR, 40)
    canv.setFillColor(MUTE)
    canv.setFont("DJV", 7.6)
    canv.drawString(ML, 28, "NSS IT Wing · INNOVEX 2026 Season 02 · Nitte University, Deralakatte")
    canv.setFont("DJV-B", 8)
    canv.drawRightString(PW - MR, 28, f"{doc.page:02d}")
    canv.restoreState()


doc = BaseDocTemplate(OUT, pagesize=A4, leftMargin=ML, rightMargin=MR,
                      topMargin=MT, bottomMargin=MB,
                      title="PRISM — Solution Description",
                      author="Team PRISM · NSS IT Wing",
                      subject="INNOVEX 2026 PS 5 · Focus Area 03 Search & Rescue")

doc.addPageTemplates([
    PageTemplate(id="cover",
                 frames=[Frame(ML, MB, CW, PH - MB - 284, id="cf",
                               leftPadding=0, rightPadding=0, topPadding=0,
                               bottomPadding=0)],
                 onPage=cover_page),
    PageTemplate(id="body",
                 frames=[Frame(ML, MB, CW, PH - MT - MB, id="bf",
                               leftPadding=0, rightPadding=0, topPadding=0,
                               bottomPadding=0)],
                 onPage=body_page),
])

# ------------------------------------------------------------------ parse ---
raw = open(SRC, encoding="utf-8").read()
lines = raw.split("\n")
flow = []
sections = []
i = 0
first_h1 = True

CARD_RE = re.compile(r"^###\s+((?:[CN]\d+))\s*·\s*(.+)$")


def collect_items(start):
    """Reads '- **Label.** text' bullets (with 2-space continuations) into
    (label, text) pairs; stops at anything that is not part of the list."""
    items = []
    j = start
    while j < len(lines):
        st = lines[j].strip()
        if st.startswith("###") or re.fullmatch(r"-{3,}", st) or st.startswith("[["):
            break
        if not st:
            # blank line: keep going only if another bullet follows
            k = j + 1
            while k < len(lines) and not lines[k].strip():
                k += 1
            if k < len(lines) and lines[k].strip().startswith("- "):
                j = k
                continue
            break
        if st.startswith("- "):
            body = st[2:]
            mb = re.match(r"^\*\*(.+?)\*\*\s*(.*)$", body)
            if mb:
                items.append([mb.group(1), mb.group(2)])
            else:
                items.append([None, body])
            j += 1
            continue
        if st and items and lines[j].startswith("  "):
            items[-1][1] += " " + st
            j += 1
            continue
        break
    return [(a.rstrip(".") if a else None, b.strip()) for a, b in items], j


while i < len(lines):
    ln = lines[i]
    s = ln.strip()

    if not s:
        i += 1
        continue

    if s == "[[FLOW]]":
        flow.append(Spacer(1, 6))
        flow.append(Flow(CW))
        flow.append(Spacer(1, 8))
        i += 1
        continue

    if re.fullmatch(r"-{3,}", s):
        if flow:                       # suppress a divider at the very top of the flow
            flow.append(Rule(CW, 0.8, RULE, 6))
        i += 1
        continue

    mc = CARD_RE.match(s)
    if mc:
        cid, ctitle = mc.group(1), mc.group(2)
        items, i = collect_items(i + 1)
        flow.append(card(cid, ctitle, items))
        flow.append(Spacer(1, 8))
        continue

    if s.startswith("### "):
        flow.append(para(s[4:], "h3"))
        i += 1
        continue

    if s.startswith("## "):
        sections.append(s[3:])
        flow.append(para(s[3:], "h2"))
        i += 1
        continue

    if s.startswith("# "):
        first_h1 = False
        i += 1
        continue

    if s.startswith("> "):
        buf = []
        while i < len(lines) and lines[i].strip().startswith(">"):
            buf.append(lines[i].strip()[1:].strip())
            i += 1
        flow.append(Spacer(1, 2))
        flow.append(callout([Paragraph(inline(" ".join(x for x in buf if x)), S["quote"])]))
        flow.append(Spacer(1, 8))
        continue

    if s.startswith("|") and i + 1 < len(lines) and re.match(r"^\|[\s:\-|]+\|$",
                                                            lines[i + 1].strip()):
        header = [c.strip() for c in s.strip("|").split("|")]
        i += 2
        rows = []
        while i < len(lines) and lines[i].strip().startswith("|"):
            rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
            i += 1
        flow.append(Spacer(1, 3))
        flow.append(mk_table(header, rows))
        flow.append(Spacer(1, 9))
        continue

    if s.startswith("- "):
        buf = [s[2:]]
        i += 1
        while (i < len(lines) and lines[i].startswith("  ") and lines[i].strip()
               and not lines[i].strip().startswith("- ")):
            buf.append(lines[i].strip())
            i += 1
        flow.append(Paragraph(inline(" ".join(buf)), S["bullet"], bulletText="•"))
        continue

    m = re.match(r"^(\d+)\.\s+(.*)$", s)
    if m:
        buf = [m.group(2)]
        i += 1
        while (i < len(lines) and lines[i].startswith("  ") and lines[i].strip()
               and not re.match(r"^(\d+\.|-)", lines[i].strip())):
            buf.append(lines[i].strip())
            i += 1
        flow.append(Paragraph(inline(" ".join(buf)), S["num"], bulletText=f"{m.group(1)}."))
        continue

    if s.startswith("**INNOVEX 2026") or s.startswith("**Problem Statement 5"):
        i += 1
        continue

    buf = [s]
    i += 1
    while (i < len(lines) and lines[i].strip()
           and not re.match(r"^(#|>|\||-|\d+\.|---|\[\[)", lines[i].strip())):
        buf.append(lines[i].strip())
        i += 1
    flow.append(para(" ".join(buf)))

# ------------------------------------------------------------------ cover ---
rows = []
for n, t in enumerate(sections, 1):
    title_only = re.sub(r"^\d+\.\s*", "", t)
    rows.append([
        Paragraph(f"<font name='DJV-B' color='#1D6FA5' size='10'>{n:02d}</font>", S["tcell"]),
        Paragraph(inline(title_only),
                  ParagraphStyle("ct", fontName="DJV", fontSize=9.5, leading=13.4,
                                 textColor=BODY)),
    ])

contents = Table(rows, colWidths=[26, CW - 26], hAlign="LEFT")
contents.setStyle(TableStyle([
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("TOPPADDING", (0, 0), (-1, -1), 4.0),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 4.0),
    ("LEFTPADDING", (0, 0), (-1, -1), 0),
    ("LINEBELOW", (0, 0), (-1, -2), 0.35, RULE),
]))

cover = [
    Spacer(1, 4),
    Paragraph("CONTENTS", S["kicker"]),
    Spacer(1, 6),
    contents,
    Spacer(1, 18),
    Paragraph("THE CLAIM THIS DOCUMENT DEFENDS", S["kicker"]),
    Spacer(1, 6),
    callout([Paragraph(
        "PRISM does not invent void-finding, triage or allocation. It makes the doctrine "
        "computable, quantified and time-aware — and it makes its own failures visible.",
        S["quote"])]),
    Spacer(1, 14),
    Paragraph("HOW TO READ THIS", S["kicker"]),
    Spacer(1, 5),
    Paragraph(
        "Section 1 is the solution in a page. <b>Section 3 maps the six failures to nine "
        "named components</b>, each specified in Section 4 with its inputs, rule, output "
        "and failure mode. <b>Section 5 defines what 95% can and cannot mean here.</b> "
        "Sections 8 and 9 give the implementation and the falsification protocol, "
        "including a kill criterion.",
        S["small"]),
    Spacer(1, 12),
    Rule(CW, 0.8, RULE, 5),
    Spacer(1, 5),
    Paragraph(
        "Document control &nbsp;·&nbsp; version 1.0 &nbsp;·&nbsp; 11 November 2026 "
        "&nbsp;·&nbsp; generated from "
        "<font name='DJV-M' size='7.4'>SOLUTION_DESCRIPTION.md</font>",
        S["small"]),
]


# ---- bind a heading to whatever comes next, including a table ----
def bind_headings(items):
    out = []
    k = 0
    while k < len(items):
        f = items[k]
        is_head = (isinstance(f, Paragraph)
                   and getattr(f.style, "name", "") in ("h2", "h3"))
        if is_head and k + 1 < len(items) and isinstance(items[k + 1], Table):
            out.append(KeepTogether([f, Spacer(1, 3), items[k + 1]]))
            k += 2
        else:
            out.append(f)
            k += 1
    return out


flow = bind_headings(flow)

story = cover + [NextPageTemplate("body"), PageBreak()] + flow
doc.build(story)

# ---- post-check: the cover must not spill into a duplicate remnant page ----
import pypdf
_r = pypdf.PdfReader(OUT)
_p1 = _r.pages[0].extract_text() or ""
_p2 = _r.pages[1].extract_text() or ""
if "Document control" not in _p1:
    raise SystemExit("BUILD FAILED: cover overflowed -- document control line left the cover")
if "NITTE UNIVERSITY" in _p2 and "CONTENTS" not in _p2:
    raise SystemExit("BUILD FAILED: duplicate cover remnant on page 2")

print(f"wrote {OUT}")
print(f"size: {os.path.getsize(OUT)/1024:.1f} KB")
