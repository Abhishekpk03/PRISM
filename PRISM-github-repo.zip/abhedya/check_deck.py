"""Heuristic overflow checker for the deck: estimates rendered text height vs available shape height."""
from pptx import Presentation
from pptx.util import Emu
import sys

EMU_IN = 914400
P = Presentation("abhedya/PRISM_pitch.pptx")
SW, SH = P.slide_width / EMU_IN, P.slide_height / EMU_IN
CH_W = 0.5      # avg glyph width as a fraction of font size (Calibri-ish, mixed case)
LINE = 1.22     # line box height multiple over (size * spacing)

problems = []
for i, slide in enumerate(P.slides, 1):
    for sh in slide.shapes:
        if not sh.has_text_frame:
            continue
        txt = sh.text_frame.text
        if not txt.strip():
            continue
        w, h = sh.width / EMU_IN, sh.height / EMU_IN
        x, y = sh.left / EMU_IN, sh.top / EMU_IN
        need = 0.0
        for p in sh.text_frame.paragraphs:
            runs = p.runs
            if not runs:
                need += 0.16
                continue
            size = max((r.font.size.pt if r.font.size else 18) for r in runs)
            spacing = p.line_spacing or 1.0
            text = "".join(r.text for r in runs)
            font = runs[0].font.name or "Calibri"
            cw = 0.62 if font == "Consolas" else CH_W
            chars_per_line = max(1, int(w / (size / 72 * cw)))
            lines = 0
            for seg in text.split("\n"):
                lines += max(1, -(-len(seg) // chars_per_line))
            need += lines * (size / 72) * spacing * LINE
        if need > h + 0.02:
            problems.append((i, round(need - h, 2), round(need, 2), round(h, 2), txt.strip().split("\n")[0][:52]))
        if y + max(need, 0.1) > SH + 0.02:
            problems.append((i, "OFFSLIDE", round(y + need, 2), round(SH, 2), txt.strip().split("\n")[0][:52]))
        if x + w > SW + 0.02:
            problems.append((i, "OFFRIGHT", round(x + w, 2), round(SW, 2), txt.strip().split("\n")[0][:52]))

print(f"slide {SW:.2f} x {SH:.2f} in · {len(P.slides)} slides · {len(problems)} flags")
for p in sorted(problems, key=lambda t: (t[0], str(t[1]))):
    print(" slide %2d  over=%s  need=%s  have=%s  | %s" % p)
