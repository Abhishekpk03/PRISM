# PRISM — Detailed Problem Statement

**INNOVEX 2026 · Season 02 · NSS IT Wing · Nitte University, Deralakatte**
**Problem Statement 5 — Project Abhedya · Focus Area 03: Search & Rescue**

---

## 1. The formal problem statement

> When a low-rise building in an Indian city collapses, rescue teams arrive at a pile of
> debris with no ranked answer to three questions: *which pockets inside this pile are
> survivable, how many people are likely in each, and which team should start where.* The
> information needed to answer them already exists — in municipal tax records, sanctioned
> plans, rental listings, structural audits, and the collapse geometry published in rescue
> doctrine — but it is never joined, never computed, and never reaches the person holding
> the shovel. The result is that allocation is decided by intuition under a survival clock
> that loses roughly **60 % of its remaining value in the first 48 hours**, while the only
> automated asset available (satellite imagery) arrives **1 to 6 days later** at a
> resolution that cannot see the buildings that fail most often.
>
> **The problem is not detecting collapse. It is deciding, in the first six hours, where a
> limited number of teams should spend a limited number of team-hours inside a pile nobody
> has mapped.**

---

## 2. Scope and setting

| Dimension | Value |
|---|---|
| Hazard | Structural collapse of low-rise load-bearing and RC-frame buildings |
| Geography | Indian urban and peri-urban; Delhi NCR used as the reference case |
| Event class | Sudden, no meaningful precursor (brittle shear / punching failure) |
| Decision window | 0–24 hours, with the decisive slope between 24 and 48 hours |
| Focus Area | 03 — Search & Rescue only. Landslide work is explicitly out of scope. |
| Build constraint | 24-hour hackathon, no hardware procurement, standard-library software |

The last row is a design constraint, not a limitation to hide. It is why the solution is a
**decision pipeline over existing data** rather than a sensor or a robot.

---

## 3. What the scene actually looks like at hour zero

1. **Nobody knows how many people are inside.** After Satya Niketan, NDRF's own public
   position was that there is *"no specific figure of trapped people."* Occupancy is
   unknown at the exact moment it matters most.
2. **The building's true load history is not on any single record.** Sanctioned plans,
   tax assessments, and what was actually built live in three different places, and in
   roughly **70 % of surveyed PG buildings in Delhi the sanctioned plan cannot be traced
   at all.**
3. **The pile has geometry, but nobody has computed it.** The type of void a collapse
   creates is described in rescue literature as *"the single most important factor in
   determining the probable location of the trapped victims"* — yet it is decided by eye,
   on arrival, after the most valuable hours have already gone.
4. **Teams are allocated by availability, not by expected benefit.** The unit of rescue is
   not a team, it is a **team-hour**, and nothing in the field compares team-hours across
   pockets.
5. **The clearance decision carries no error bar.** A structure is marked clear on a
   doctrine that is sound but inconsistently known — in one post-earthquake survey only
   **47.4 %** of responders correctly identified the Clear marking.
6. **Responders are being injured by the map they do not have.** In Nepal, **55.5 % of 239
   responder injuries** came from falling into holes concealed by loose rubble — voids that
   a prior map would have marked before anyone stepped on the pile.

---

## 4. Gap analysis — six exact failure points

Each failure point is stated as *what happens*, *the number that proves it*, and *why the
existing tools do not close it.*

### F1 · No pre-event queue: the city knows which buildings are dangerous but cannot rank them

- **What happens.** Structural audit in India is paper-based, per-engineer, produces no
  comparable Safety Index, and never reaches a rescue commander.
- **The number.** MCD surveyed **30.7 lakh properties and classified 62 as dangerous.**
  That is a list, not a queue — it carries no estimate of *when*, *how*, or *how many
  people*, and it does not survive the transition to a rescue operation.
- **Why not closed.** FEMA P-154 rapid visual screening exists and scores buildings, and
  India has an RVS variant (Sinha & Goyal) plus IS 15988:2013. None of them is wired to a
  live occupancy record, and none produces a rescue-relevant output. **RVS tells an engineer
  what to inspect. It does not tell a commander what to expect.**

### F2 · Collapse mechanism is inferred on arrival, qualitatively, when it could be computed beforehand

- **What happens.** Void location is the dominant predictor of where survivors are, and it
  is currently a judgement made by eye at the pile.
- **The number.** Six mechanisms are documented with published void geometry and fatality
  rates — pancake carries **57.9 % entrapment fatality**, weak ground floor **35.9 %**,
  while supported and unsupported lean-to voids are both the **most common** and the most
  survivable. These are known distributions being applied as rules of thumb.
- **Why not closed.** FEMA USAR scores a **building**, not a pocket, and it scores on
  arrival. INSARAG marks voids during the search. **The geometry is doctrine in prose; it
  has never been computed into a spatial prior, ranked, and handed over before the teams
  land.**

### F3 · Survivable pockets are never enumerated, so effort is spent on zero-yield volumes

- **What happens.** Teams clear where a victim was heard or seen, then clear outward. In a
  pancake pile the layered voids between slabs are small and the fatality rate is high; in
  a lean-to the void under the raised end is large and survival is good. Clearing the first
  before the second is a loss of lives that no one records.
- **The number.** **~74 % of casualties are trapped, and ~45 % of those trapped die.** The
  difference between the two mechanisms is the difference between a majority dying and a
  majority living.
- **Why not closed.** Doctrine says lean-to voids offer *"an excellent chance"* and should
  be hunted first — but the pile gives no label. GPR studies confirm lean-to voids are
  detectable, but GPR is **one probe, one point, one operator**, deployed after arrival.

### F4 · Allocation ignores the survival clock and the rate

- **What happens.** Teams are assigned to pockets by proximity, by report order, or by
  whoever shouts loudest.
- **The number.** Survival of the entrapped falls **91 % at 30 minutes → 81 % at 1 day →
  36.7 % at 2 days → 19 % at 4 days**, and **89 % of live rescues in Armenia 1988 happened
  in the first 24 hours.** A ranking that does not change as the clock runs is a ranking
  that is wrong by hour twelve.
- **Why not closed.** The optimisation exists in research — a USAR team-deployment
  stochastic program (2012), and the **ReSTART** result (Mills, Argon, Ziya et al. 2014)
  showing that under **severe resource constraint, salvageable casualties should be served
  before critical ones.** None of it is in the field, because none of it has an input
  stream. **The maths is solved; the data pipe is not built.**

### F5 · The records that would answer everything are never joined

- **What happens.** A PG building's sanctioned floors sit with the municipality, its actual
  floors sit in a rental listing, and its actual headcount sits in neither.
- **The number.** Delhi's Unit Area System assigns a **15-digit UPIC** to every property and
  computes tax from declared covered area, occupancy, use and age; MCD's own 3D-mapping
  pilot exists specifically to catch *"under-reported built-up area — paying tax for fewer
  floors."* In the PG survey, **2,453 buildings held 50,529 occupants while 70 % of plans
  were untraceable.** The mismatch is already the municipality's own stated problem.
- **Why not closed.** Nobody joins the two datasets to ask a rescue question. **A declared
  G+1 against a listing that advertises six floors is a load ratio of 3.0, computed in
  seconds, for free — and it predicts the mechanism.** That join is not part of any rescue
  workflow that exists today.

### F6 · The only genuinely instant channels are unwired

- **What happens.** The commander's fastest information is a human phone call. Nothing
  automated is faster.
- **The number.** Free optical imagery is **10 m with a ~5-day revisit**; SAR is **6–12
  days**; damage maps arrive **1–6 days later at ~100 m** and cannot separate heavily
  damaged from collapsed. Post-event SAR alone scores around **0.55**; the best optical
  models reach **F1 ≈ 0.80** but wait **2–6 weeks** for cloud-free data. At Satya Niketan
  the plot is **46 m² — 0.46 of a single pixel.** The sixth floor is physically invisible
  to the free sensor.
- **Why not closed.** Satellite cannot be the trigger. **The instant channels are a citizen
  photograph and a sensor mounted inside the structural element** — and neither is currently
  connected to a decision. A last-gasp accelerometer that reports *impact count* and
  *collapse duration* can distinguish a pancake stack from a progressive lean-to in under a
  second; that packet exists as an idea, not as a product.

---

## 5. Why the obvious answers do not solve it

Stated plainly, because overstating novelty is how this kind of work fails review.

| Tempting claim | Reality |
|---|---|
| "Every rival is single-modality" | **False.** Multi-sensor fusion is an active published field (e.g. MDPI *Sensors* 18(3):852). |
| "Nobody has a void prior" | **Overstated.** FEMA and INSARAG both encode void reasoning in doctrine. |
| "Silence is uninterpretable" | **Flatly false.** FEMA defines a null search as *"'0' = no victims"*, and INSARAG has a Clear mark. |
| "Satellite can see the collapse in real time" | **False.** 1–6 days, ~100 m, no severity grading. |
| "We will predict collapse" | **Overclaimed.** Brittle shear failure gives little to no precursor. Tilt alarms and SHM work on creep and long-term degradation, not on this failure class. |
| "We will build a nanobot swarm / X-ray vision" | **Physically impossible** in the window: RF skin depth is 0.171 m at 866 MHz, and a mm³ mote holds ~1 joule — enough to listen, not to walk. |

**What actually survives scrutiny** is narrower and defensible:

1. Clearance is doctrine, but only **47.4 %** of responders know the Clear marking.
2. The void prior exists **qualitatively** — it is never computed, ranked, or delivered
   before arrival.
3. **No system attaches an error rate or an evidence trail to a clearance decision.**

---

## 6. Who has this problem

| Actor | What they need at hour zero | What they get today |
|---|---|---|
| NDRF / SDRF rescue commander | a ranked list of pockets with time-to-entry | a pile, a phone, and experience |
| Municipal engineer (MCD) | a queue of buildings by expected consequence | 30.7 lakh records, 62 flagged, no order |
| Building owner / PG operator | an early warning with a liability trail | a paper audit nobody reads |
| Trapped occupant | someone arriving at the right pocket first | whoever was heard first |

---

## 7. What "solved" looks like — measurable success criteria

The problem is solved when, for a given collapsed building, a system produces within
seconds and offline:

1. **A standing band** for every building in the queue, derived from records alone, with
   the load ratio printed and its verifiability stated (`RED / AMBER / GREEN`).
2. **A mechanism posterior** over the six known classes, with an explicit
   **`UNCERTAIN / novel`** output when no class exceeds 0.60 or the structure type is
   outside the model's vocabulary — *never a confident lie*.
3. **An enumerated void field** — pockets with zone, floor, volume, clearing effort, search
   probability, and expected persons inside.
4. **A survival clock** attached to each pocket, so the ranking changes on its own as hours
   pass, without new input.
5. **A ranked allocation** in **expected lives per team-hour**, with ETAs, an expectant
   list that is re-triaged rather than written off, and an explicit statement of which
   pockets cannot be reached in time.
6. **Every number carrying its own error bar.** The assumptions, and the direction each one
   would bias the answer, printed at the end of every run.
7. **Surviving attack.** A published adversarial test suite — the current implementation
   passes **10 of 10**, including tests that refuse to output the word *dead* and that
   refuse to treat sensor silence as proof a pocket is empty.

**Demonstrable in five minutes, with no hardware:** three teams → one team → blank the
records. The plan reorders, pockets fall off the end, and the system *says so*. A system
that degrades honestly is more convincing than one that looks perfect on a single case.

---

## 8. Explicit boundaries

**In scope:** structural collapse, search and rescue, decision support, open-data
integration, offline operation.

**Out of scope, deliberately:** landslide prediction (one slide only), any claim of
collapse prediction, any claim of real-time satellite detection, any robotics or sensing
hardware, and any output that states a person is dead.

---

## 9. The one-sentence version

> **PRISM does not invent void-finding, triage, or allocation. It makes the doctrine
> computable, quantified, and time-aware — and it attaches an error rate to every number it
> prints.**

---

### Sources for the numbers above

**Rescue doctrine and triage**

1. FEMA P-154, *Rapid Visual Screening of Buildings for Potential Seismic Hazards*; and the FEMA USAR structural triage scoring factors.
2. INSARAG Guidelines, Volume II (GRA 2.1) — void marking, and the Clear marking convention.
3. SALT mass-casualty triage (Cambridge DMPHP, 2013), including the Expectant category as a resource judgement.
4. Mills, Argon, Ziya et al. (2014), *ReSTART* — prioritisation under severe resource constraint.
5. USAR team-deployment multistage stochastic program (2012) — expected-lives allocation with diminishing survival.

**Casualty and survival modelling**

6. NSF rubble-void survival study — survival of the entrapped at 30 min, 1 day, 2 days and 4 days.
7. Coburn & Spence casualty model — structural damage share of fatalities; pancake entrapment fatality rate.
8. UDel DRC 350a trapped-fraction model; Armenia 1988 field data on live rescues within 24 hours.
9. Nepal 2015 responder-injury survey — injuries caused by concealed voids under loose rubble.

**Collapse mechanism and void geometry**

10. Fire Engineering and AllFirefighter published void taxonomy — six mechanisms, void location and survivability per mechanism.

**Indian official and municipal records**

11. MCD Unit Area System and the 15-digit UPIC property identifier; MCD OBPS online sanction portal.
12. MCD PG building survey; MCD dangerous-building classification; MCD 3D-mapping pilot for under-reported built-up area.

**Satellite and remote sensing**

13. Sentinel-1 and Sentinel-2 mission specifications — resolution and revisit interval.
14. SAR damage-proxy and optical damage-assessment studies, including the xBD benchmark, on recall and severity grading limits.

**Public record**

15. NDRF public statements and press reporting on the Satya Niketan and Mehrauli collapses.

Every figure quoted here is reproduced in `abhedya/prism/PIPELINE.md` and generated live by
`abhedya/prism/pipeline.py`; the deck `abhedya/PRISM_pipeline.pptx` reads the same values at
build time, so document, code and slides cannot disagree.
