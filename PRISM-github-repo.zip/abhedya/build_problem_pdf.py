"""
build_problem_pdf.py
Renders PROBLEM_STATEMENT.md -> PRISM_Problem_Statement.pdf

The markdown is the single source of truth: this parses it rather than
re-authoring the text, so the document and the PDF cannot drift apart.

Typography: DejaVu (the only family here with a complete Unicode set, so the
arrows, multiplication signs and Greek letters in the formulas render properly).

Run:  python3 build_problem_pdf.py
"""

import os
import re

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, Flowable, Frame, KeepTogether,
                                NextPageTemplate, PageBreak, PageTemplate,
                                Paragraph, Spacer, Table, TableStyle)

BASE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(BASE, "PROBLEM_STATEMENT.md")
OUT = os.path.join(BASE, "PRISM_Problem_Statement.pdf")
FDIR = "/usr/share/fonts/truetype/dejavu"

# ------------------------------------------------------------------- fonts --
pdfmetrics.registerFont(TTFont("DJV", f"{FDIR}/DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DJV-B", f"{FDIR}/DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("DJV-M", f"{FDIR}/DejaVuSansMono.ttf"))
pdfmetrics.registerFont(TTFont("DJV-S", f"{FDIR}/DejaVuSerif.ttf"))
pdfmetrics.registerFont(TTFont("DJV-SB", f"{FDIR}/DejaVuSerif-Bold.ttf"))
# italic maps to the serif face: same size, clearly differentiated in a sans line
pdfmetrics.registerFontFamily("DJV", normal="DJV", bold="DJV-B",
                              italic="DJV-S", boldItalic="DJV-SB")

# ----------------------------------------------------------------- palette --
NAVY = colors.HexColor("#16233A")
NAVY_L = colors.HexColor("#2A3D5C")
AMBER = colors.HexColor("#B8730A")
INK = colors.HexColor("#1A1A1A")
BODY = colors.HexColor("#232A33")
MUTE = colors.HexColor("#5B6B7C")
RULE = colors.HexColor("#D5DCE4")
WASH = colors.HexColor("#F4F6F9")
WASH_A = colors.HexColor("#FBF3E4")
RED = colors.HexColor("#A3291F")
GREEN = colors.HexColor("#1C6B45")

PW, PH = A4
ML = MR = 54
MT, MB = 62, 56
CW = PW - ML - MR

# ------------------------------------------------------------------ styles --
S = {}


def mk(name, **kw):
    base = dict(name=name, fontName="DJV", fontSize=9.4, leading=14.2,
                textColor=BODY, alignment=TA_LEFT, spaceBefore=0, spaceAfter=0,
                allowWidows=0, allowOrphans=0)
    base.update(kw)
    S[name] = ParagraphStyle(**base)
    return S[name]


mk("h1", fontName="DJV-B", fontSize=21, leading=25, textColor=NAVY, spaceAfter=2)
mk("h2", fontName="DJV-B", fontSize=13.2, leading=17, textColor=NAVY,
   spaceBefore=17, spaceAfter=7, keepWithNext=1)
mk("h3", fontName="DJV-B", fontSize=10.4, leading=14, textColor=AMBER,
   spaceBefore=11, spaceAfter=4, keepWithNext=1)
mk("body", spaceAfter=7)
mk("lead", fontSize=10.2, leading=15.6, textColor=BODY, spaceAfter=8)
mk("bullet", leftIndent=13, bulletIndent=2, spaceAfter=4)
mk("num", leftIndent=17, bulletIndent=2, spaceAfter=4)
mk("quote", fontName="DJV-S", fontSize=11.2, leading=17, textColor=NAVY,
   leftIndent=13, rightIndent=6, spaceBefore=2, spaceAfter=2)
mk("tcell", fontSize=8.6, leading=11.8, textColor=BODY)
mk("thead", fontName="DJV-B", fontSize=8.3, leading=11.4, textColor=colors.white)
mk("kicker", fontName="DJV-B", fontSize=8.4, leading=11, textColor=AMBER)
mk("small", fontSize=8.3, leading=12.2, textColor=MUTE)
mk("fbwhat", spaceAfter=3)
mk("fnum", fontName="DJV-M", fontSize=8.5, leading=12.4, textColor=RED)


# ------------------------------------------------------------------ inline --
def inline(t):
    t = (t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"(?<!\*)\*([^*]+?)\*(?!\*)", r"<i>\1</i>", t)
    t = re.sub(r"`(.+?)`", r'<font name="DJV-M" size="8.3">\1</font>', t)
    return t


def para(text, style="body"):
    return Paragraph(inline(text), S[style])


# ------------------------------------------------------------------ tables --
def fit_widths(header, rows, pad=11.0, size_h=8.3, size_c=8.6):
    """Column widths that never break a single word.

    Proportional to content, then floors enforced using EXACT string widths from
    the font metrics, then any remaining deficit is taken only from columns that
    still have slack. A naive floor-then-normalise pass re-shrinks the columns it
    just protected, which is how 'Determinism' got split mid-word.
    """
    ncols = len(header)
    floors, wants = [], []
    for c in range(ncols):
        cells = [header[c]] + [r[c] for r in rows]
        longest_word = max((w for cell in cells for w in str(cell).split()), key=len,
                           default="mm")
        fw = pdfmetrics.stringWidth(longest_word, "DJV-B", size_h)
        floors.append(fw + pad + 2)
        widest = max((pdfmetrics.stringWidth(str(x), "DJV", size_c) for x in cells),
                     default=40.0)
        wants.append(max(widest + pad, floors[-1]))

    # 1. proportional first, 2. lift any column to its floor, 3. take the excess
    #    only from columns that still have slack. Iterate until stable -- doing the
    #    floor BEFORE the proportional split silently un-does it on renormalisation.
    tot = sum(wants)
    widths = [CW * w / tot for w in wants]

    for _ in range(80):
        for k in range(ncols):
            if widths[k] < floors[k] - 1e-6:
                widths[k] = floors[k]
        excess = sum(widths) - CW
        if excess <= 0.2:
            break
        slack = [max(0.0, widths[k] - floors[k]) for k in range(ncols)]
        tot_slack = sum(slack)
        if tot_slack <= 0.2:
            break
        widths = [widths[k] - excess * slack[k] / tot_slack for k in range(ncols)]

    if sum(widths) < CW - 0.2:                 # grow to fill the measure
        short = CW - sum(widths)
        widths = [widths[k] + short * wants[k] / tot for k in range(ncols)]
    return widths


def mk_table(header, rows, widths=None):
    ncols = len(header)
    if widths is None:
        widths = fit_widths(header, rows)

    data = [[Paragraph(inline(c), S["thead"]) for c in header]]
    for r in rows:
        data.append([Paragraph(inline(c), S["tcell"]) for c in r])

    t = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    st = [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, RULE),
        ("LINEBELOW", (0, 0), (-1, 0), 0.8, NAVY),
    ]
    for i in range(1, len(data)):
        if i % 2 == 0:
            st.append(("BACKGROUND", (0, i), (-1, i), WASH))
    t.setStyle(TableStyle(st))
    return t


# ---------------------------------------------------------------- callouts --
class Rule(Flowable):
    def __init__(self, w, thickness=0.8, col=RULE, pad=6):
        Flowable.__init__(self)
        self.w, self.t, self.c, self.pad = w, thickness, col, pad
        self.height = thickness + pad * 2

    def draw(self):
        self.canv.setStrokeColor(self.c)
        self.canv.setLineWidth(self.t)
        self.canv.line(0, self.pad, self.w, self.pad)


def callout(flowables, border=AMBER, bg=WASH_A):
    """A block with a heavy coloured left rule -- used for the formal statement."""
    t = Table([[flowables]], colWidths=[CW], hAlign="LEFT")
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), bg),
        ("LINEBEFORE", (0, 0), (0, -1), 3.2, border),
        ("TOPPADDING", (0, 0), (-1, -1), 11),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 11),
        ("LEFTPADDING", (0, 0), (-1, -1), 13),
        ("RIGHTPADDING", (0, 0), (-1, -1), 13),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    return t


def fail_block(fid, title, what, number, why):
    inner = [
        Paragraph(f"<font name='DJV-B' size='12' color='#B8730A'>{fid}</font>"
                  f"&nbsp;&nbsp;<font name='DJV-B' size='10.6' color='#16233A'>{inline(title)}</font>",
                  S["body"]),
        Spacer(1, 3),
        Paragraph(f"<b>What happens.</b> {inline(what)}", S["fbwhat"]),
        Paragraph(f"<b>The number.</b> {inline(number)}", S["fbwhat"]),
        Paragraph(f"<b>Why it is not closed.</b> {inline(why)}", S["fbwhat"]),
    ]
    t = Table([[inner]], colWidths=[CW], hAlign="LEFT")
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.white),
        ("LINEBEFORE", (0, 0), (0, -1), 2.6, NAVY_L),
        ("BOX", (0, 0), (-1, -1), 0.4, RULE),
        ("TOPPADDING", (0, 0), (-1, -1), 9),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 9),
        ("LEFTPADDING", (0, 0), (-1, -1), 12),
        ("RIGHTPADDING", (0, 0), (-1, -1), 11),
    ]))
    return KeepTogether([t, Spacer(1, 8)])


# ------------------------------------------------------------- page frames --
def cover_page(canv, doc):
    canv.saveState()
    band_h = 250
    canv.setFillColor(NAVY)
    canv.rect(0, PH - band_h, PW, band_h, stroke=0, fill=1)
    canv.setFillColor(AMBER)
    canv.rect(0, PH - band_h - 4, PW, 4, stroke=0, fill=1)

    canv.setFillColor(AMBER)
    canv.setFont("DJV-B", 8.6)
    canv.drawString(ML, PH - 62,
                    "INNOVEX 2026  ·  SEASON 02  ·  NSS IT WING  ·  NITTE UNIVERSITY")

    canv.setFillColor(colors.white)
    canv.setFont("DJV-B", 46)
    canv.drawString(ML - 2, PH - 128, "PRISM")

    canv.setFillColor(colors.HexColor("#C9D4E2"))
    canv.setFont("DJV", 15.5)
    canv.drawString(ML, PH - 158, "Detailed Problem Statement")

    canv.setFillColor(colors.HexColor("#8FA3BC"))
    canv.setFont("DJV", 9.4)
    canv.drawString(ML, PH - 184,
                    "Problem Statement 5  —  Project Abhedya")
    canv.drawString(ML, PH - 199,
                    "Focus Area 03  —  Search & Rescue")
    canv.drawString(ML, PH - 214,
                    "Structural collapse · Indian urban low-rise · 24-hour decision window")

    canv.setStrokeColor(colors.HexColor("#3C4F6E"))
    canv.setLineWidth(0.6)
    canv.line(ML, PH - 226, PW - MR, PH - 226)

    canv.setFillColor(colors.HexColor("#6E8099"))
    canv.setFont("DJV", 8)
    canv.drawString(ML, 34, "PRISM / Problem Statement")
    canv.setFont("DJV-B", 8)
    canv.drawRightString(PW - MR, 34, "01")
    canv.restoreState()


def body_page(canv, doc):
    canv.saveState()
    canv.setStrokeColor(RULE)
    canv.setLineWidth(0.6)
    canv.line(ML, PH - 44, PW - MR, PH - 44)
    canv.setFillColor(MUTE)
    canv.setFont("DJV-B", 7.6)
    canv.drawString(ML, PH - 38, "PRISM  ·  DETAILED PROBLEM STATEMENT")
    canv.setFont("DJV", 7.6)
    canv.drawRightString(PW - MR, PH - 38, "Focus Area 03 · Search & Rescue")

    canv.setStrokeColor(RULE)
    canv.line(ML, 40, PW - MR, 40)
    canv.setFillColor(MUTE)
    canv.setFont("DJV", 7.6)
    canv.drawString(ML, 28, "NSS IT Wing · INNOVEX 2026 Season 02 · Nitte University, Deralakatte")
    canv.setFont("DJV-B", 8)
    canv.drawRightString(PW - MR, 28, f"{doc.page:02d}")
    canv.restoreState()


doc = BaseDocTemplate(OUT, pagesize=A4, leftMargin=ML, rightMargin=MR,
                      topMargin=MT, bottomMargin=MB,
                      title="PRISM — Detailed Problem Statement",
                      author="Team PRISM · NSS IT Wing",
                      subject="INNOVEX 2026 PS 5 · Focus Area 03 Search & Rescue")

cover_frame = Frame(ML, MB, CW, PH - MB - 300, id="coverf",
                    leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
body_frame = Frame(ML, MB, CW, PH - MT - MB, id="bodyf",
                   leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)

doc.addPageTemplates([
    PageTemplate(id="cover", frames=[cover_frame], onPage=cover_page),
    PageTemplate(id="body", frames=[body_frame], onPage=body_page),
])

# ------------------------------------------------------------------ parse ---
raw = open(SRC, encoding="utf-8").read()
lines = raw.split("\n")

flow = []
sections = []
i = 0
first_h1 = True
seen_formal = False

while i < len(lines):
    ln = lines[i]
    s = ln.strip()

    if not s:
        i += 1
        continue

    # horizontal rule
    if re.fullmatch(r"-{3,}", s):
        flow.append(Rule(CW, 0.8, RULE, 7))
        i += 1
        continue

    # ---- failure blocks: ### F<n> · title  followed by three labelled bullets ----
    mf = re.match(r"^###\s+(F\d)\s*·\s*(.+)$", s)
    if mf:
        fid, ftitle = mf.group(1), mf.group(2)
        i += 1
        parts, cur = {}, None
        while i < len(lines):
            t = lines[i]
            st_ = t.strip()
            if st_.startswith("###") or re.fullmatch(r"-{3,}", st_):
                break
            if st_.startswith("- "):
                body = st_[2:]
                mb = re.match(r"\*\*(What happens|The number|Why not closed)\.?\*\*\s*(.*)",
                              body)
                if mb:
                    cur = mb.group(1)
                    parts[cur] = [mb.group(2)]
                else:
                    cur = cur or str(len(parts))
                    parts.setdefault(cur, []).append(body)
            elif st_ and cur and t.startswith("  "):
                parts[cur].append(st_)
            i += 1
        g = lambda k: " ".join(parts.get(k, [""])).strip()   # fail_block escapes once
        flow.append(fail_block(fid, ftitle, g("What happens"), g("The number"),
                               g("Why not closed")))
        continue

    # headings
    if s.startswith("### "):
        flow.append(para(s[4:], "h3"))
        i += 1
        continue
    if s.startswith("## "):
        txt = s[3:]
        sections.append(txt)
        flow.append(para(txt, "h2"))
        i += 1
        continue
    if s.startswith("# "):
        # the H1 is drawn on the cover; skip it there
        if first_h1:
            first_h1 = False
        else:
            flow.append(para(s[2:], "h1"))
        i += 1
        continue

    # blockquote -> pull quote
    if s.startswith("> "):
        buf = []
        while i < len(lines) and lines[i].strip().startswith(">"):
            buf.append(lines[i].strip()[1:].strip())
            i += 1
        text = " ".join(x for x in buf if x)
        flow.append(Spacer(1, 2))
        flow.append(callout([Paragraph(inline(text), S["quote"])], AMBER, WASH_A))
        flow.append(Spacer(1, 8))
        seen_formal = True
        continue

    # table
    if s.startswith("|") and i + 1 < len(lines) and re.match(r"^\|[\s:\-|]+\|$", lines[i + 1].strip()):
        header = [c.strip() for c in s.strip("|").split("|")]
        i += 2
        rows = []
        while i < len(lines) and lines[i].strip().startswith("|"):
            rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
            i += 1
        flow.append(Spacer(1, 3))
        flow.append(mk_table(header, rows))
        flow.append(Spacer(1, 9))
        continue

    # bullets (with 2-space continuation lines folded back in)
    if s.startswith("- "):
        while i < len(lines) and lines[i].strip().startswith("- "):
            buf = [lines[i].strip()[2:]]
            i += 1
            while (i < len(lines) and lines[i].startswith("  ")
                   and lines[i].strip() and not lines[i].strip().startswith("- ")):
                buf.append(lines[i].strip())
                i += 1
            flow.append(Paragraph(inline(" ".join(buf)), S["bullet"], bulletText="•"))
        continue

    # numbered (with 2-space continuation lines folded back in)
    m = re.match(r"^(\d+)\.\s+(.*)$", s)
    if m:
        n = m.group(1)
        buf = [m.group(2)]
        i += 1
        while (i < len(lines) and lines[i].startswith("  ") and lines[i].strip()
               and not re.match(r"^(\d+\.|-)", lines[i].strip())):
            buf.append(lines[i].strip())
            i += 1
        flow.append(Paragraph(inline(" ".join(buf)), S["num"], bulletText=f"{n}."))
        continue

    # the identity block is drawn on the cover; do not repeat it in the body
    if s.startswith("**INNOVEX 2026") or s.startswith("**Problem Statement 5"):
        i += 1
        continue

    # paragraph (join wrapped lines)
    buf = [s]
    i += 1
    while (i < len(lines) and lines[i].strip() and
           not re.match(r"^(#|>|\||-|\d+\.|---)", lines[i].strip())):
        buf.append(lines[i].strip())
        i += 1
    flow.append(para(" ".join(buf)))

# --------------------------------------------------------------- assemble --
contents_rows = []
for n, t in enumerate(sections, 1):
    num, _, rest_t = t.partition("·")
    title_only = re.sub(r"^\d+\.\s*", "", t)
    contents_rows.append([
        Paragraph(f"<font name='DJV-B' color='#B8730A' size='10'>{n:02d}</font>",
                  S["tcell"]),
        Paragraph(inline(title_only), ParagraphStyle("ct", fontName="DJV", fontSize=9.6,
                                                     leading=13.6, textColor=BODY)),
    ])

contents = Table(contents_rows, colWidths=[26, CW - 26], hAlign="LEFT")
contents.setStyle(TableStyle([
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("TOPPADDING", (0, 0), (-1, -1), 4.5),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 4.5),
    ("LEFTPADDING", (0, 0), (-1, -1), 0),
    ("LINEBELOW", (0, 0), (-1, -2), 0.35, RULE),
]))

cover = [
    Spacer(1, 6),
    Paragraph("CONTENTS", S["kicker"]),
    Spacer(1, 7),
    contents,
    Spacer(1, 20),
    Paragraph("HOW TO READ THIS", S["kicker"]),
    Spacer(1, 6),
    Paragraph(
        "Sections 1 to 3 state the problem and the scene. <b>Section 4 is the gap "
        "analysis</b> the problem statement asks for: six failure points, each with the "
        "number that proves it and the reason existing tools do not close it. Section 5 "
        "exists to stop us overclaiming. Sections 6 to 8 define the user, the measurable "
        "success criteria, and the boundary of what is in scope. "
        "Every figure is traceable; the sources are listed on the final page.",
        S["small"]),
    Spacer(1, 22),
    Paragraph("THESIS", S["kicker"]),
    Spacer(1, 6),
    callout([Paragraph(
        "PRISM does not invent void-finding, triage, or allocation. It makes the "
        "doctrine computable, quantified and time-aware — and it attaches an error "
        "rate to every number it prints.", S["quote"])]),
    Spacer(1, 16),
    Rule(CW, 0.8, RULE, 5),
    Spacer(1, 6),
    Paragraph(
        "Document control &nbsp;·&nbsp; version 1.0 &nbsp;·&nbsp; 11 November 2026 "
        "&nbsp;·&nbsp; generated from <font name='DJV-M' size='7.4'>PROBLEM_STATEMENT.md</font>",
        S["small"]),
]


# ---- bind a heading to whatever comes next, including a table ----
def bind_headings(items):
    out = []
    k = 0
    while k < len(items):
        f = items[k]
        is_head = (isinstance(f, Paragraph)
                   and getattr(f.style, "name", "") in ("h2", "h3"))
        if is_head and k + 1 < len(items) and isinstance(items[k + 1], Table):
            out.append(KeepTogether([f, Spacer(1, 3), items[k + 1]]))
            k += 2
        else:
            out.append(f)
            k += 1
    return out


flow = bind_headings(flow)

story = cover + [NextPageTemplate("body"), PageBreak()] + flow

doc.build(story)
print(f"wrote {OUT}")
print(f"size: {os.path.getsize(OUT)/1024:.1f} KB")
