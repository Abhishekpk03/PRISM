"""
verify_deck.py -- geometry and content audit for PRISM_pipeline.pptx

LibreOffice is not available in this environment, so the deck cannot be
rasterised. This checks what can be checked without rendering:

  1. every shape is inside the slide
  2. no two TEXT boxes overlap (panels under text are expected, text on text is not)
  3. every slide has speaker notes
  4. no slide is text-starved or text-flooded
  5. charts have no white plot area on the dark background
  6. no orphan placeholders or empty shapes

Run:  python3 verify_deck.py
"""

import sys
from pptx import Presentation
from pptx.util import Emu

PPTX = "PRISM_pipeline.pptx"
EMU_IN = 914400.0

prs = Presentation(PPTX)
W, H = prs.slide_width / EMU_IN, prs.slide_height / EMU_IN
problems = []
stats = []


def bbox(sh):
    return (sh.left / EMU_IN, sh.top / EMU_IN,
            (sh.left + sh.width) / EMU_IN, (sh.top + sh.height) / EMU_IN)


def overlap(a, b):
    x = min(a[2], b[2]) - max(a[0], b[0])
    y = min(a[3], b[3]) - max(a[1], b[1])
    return max(0.0, x) * max(0.0, y)


for i, slide in enumerate(prs.slides, 1):
    texts, charts, shapes = [], 0, 0
    chars = 0
    for sh in slide.shapes:
        shapes += 1
        x0, y0, x1, y1 = bbox(sh)
        if x0 < -0.02 or y0 < -0.02 or x1 > W + 0.02 or y1 > H + 0.02:
            problems.append(f"slide {i}: shape out of bounds {(round(x0,2), round(y0,2), round(x1,2), round(y1,2))}")
        if sh.has_chart:
            charts += 1
            xml = sh.chart._chartSpace.xml
            if "a:noFill" not in xml:
                problems.append(f"slide {i}: chart plot area may be filled (white box)")
        if sh.has_text_frame and sh.text_frame.text.strip():
            t = sh.text_frame.text
            chars += len(t)
            # ignore the full-bleed background rectangle and 1-2 char bullets
            if len(t.strip()) > 2:
                texts.append((bbox(sh), t[:40]))

    # text-on-text overlap
    for a in range(len(texts)):
        for b in range(a + 1, len(texts)):
            ov = overlap(texts[a][0], texts[b][0])
            if ov > 0.05:
                problems.append(
                    f"slide {i}: text overlap {ov:.2f} in² "
                    f"({texts[a][1]!r} vs {texts[b][1]!r})")

    notes = ""
    if slide.has_notes_slide:
        notes = slide.notes_slide.notes_text_frame.text.strip()
    if len(notes.split()) < 25:
        problems.append(f"slide {i}: speaker notes missing or too thin ({len(notes.split())} words)")

    if chars > 1500:
        problems.append(f"slide {i}: {chars} characters -- too dense for one slide")
    if chars < 160:
        problems.append(f"slide {i}: only {chars} characters -- slide may be near-empty")

    stats.append((i, shapes, charts, chars, len(notes.split())))

print(f"{PPTX}: {len(prs.slides)} slides, {W:.2f} x {H:.2f} in")
print(f"{'slide':>5}{'shapes':>8}{'charts':>8}{'chars':>8}{'notes w':>9}")
for i, sh_, ch_, c_, n_ in stats:
    print(f"{i:>5}{sh_:>8}{ch_:>8}{c_:>8}{n_:>9}")

total_chars = sum(s[3] for s in stats)
total_notes = sum(s[4] for s in stats)
print(f"\ntotal: {total_chars} chars on slides, {total_notes} words of notes "
      f"(~{total_notes/140:.1f} min spoken)")

if problems:
    print(f"\n{len(problems)} PROBLEMS")
    for p in problems:
        print("  !", p)
    sys.exit(1)
print("\n0 problems")
