"""Independent re-derivation of every headline claim. No reuse of analysis.py code paths."""
import math, json, numpy as np

ok = lambda c: "PASS" if c else "**FAIL**"
rows = []

# ---------- 1. PPV table
def ppv(p, t, f): return p*t/(p*t + (1-p)*f)
checks = [
 ("PPV k=1 prior 1e-3", ppv(1e-3,.9,.2), 0.0045),
 ("PPV k=1 prior 1e-2", ppv(1e-2,.9,.2), 0.0435),
 ("PPV k=1 prior 0.1",  ppv(0.1,.9,.2), 0.3333),
 ("PPV k=2 prior 0.1",  ppv(0.1,.81,.04), 0.6923),
 ("PPV k=3 prior 0.1",  ppv(0.1,.729,.008), 0.9101),
 ("PPV k=3 prior 0.5",  ppv(0.5,.729,.008), 0.9891),
]
for name, got, want in checks:
    rows.append((name, round(got,4), want, ok(abs(got-want) < 6e-4)))

# ---------- 2. FPR needed for 99% PPV at prior 0.01
f_need = (0.01*0.9/0.99 - 0.01*0.9)/(1-0.01)
rows.append(("FPR needed for 0.99 PPV @prior 0.01", round(f_need,6), 0.0000909, ok(abs(f_need-9.09e-5)<2e-6)))

# ---------- 3. required per-channel LR
def lr_req(p, T=0.99): return (T/(1-T))/(p/(1-p))
for p, want1, want3 in [(1e-4, 989901, 100), (1e-2, 9801, 21)]:
    got1 = lr_req(p); got3 = lr_req(p)**(1/3)
    rows.append((f"LR req k=1 prior {p}", round(got1), want1, ok(abs(got1-want1)/want1 < .01)))
    rows.append((f"LR req k=3 prior {p}", round(got3), want3, ok(abs(got3-want3) <= 1.2)))

# ---------- 4. SPRT
alpha, beta = 1e-3, 0.05
A = math.log((1-beta)/alpha); B = math.log(beta/(1-alpha))
rows.append(("SPRT A (log)", round(A,2), 6.86, ok(abs(A-6.86)<.01)))
rows.append(("SPRT B (log)", round(B,2), -2.99, ok(abs(B+2.99)<.01)))
for l1,l0,wn1,wn0 in [(1.6,-0.9,4.0,3.3)]:
    en1 = ((1-beta)*A + beta*B)/l1; en0 = ((1-alpha)*B + alpha*A)/l0
    rows.append(("E[samples|H1] @LLR 1.6", round(en1,1), wn1, ok(abs(en1-wn1)<.15)))
    rows.append(("E[samples|H0] @LLR -0.9", round(en0,1), wn0, ok(abs(en0-wn0)<.15)))

# ---------- 5. coverage
m=0.15
for k, want in [(1,.85),(2,.9775),(4,.99949),(5,.99992)]:
    got = 1-m**k
    rows.append((f"coverage m=.15 k={k}", round(got,5), want, ok(abs(got-want)<1e-4)))
rows.append(("passes for 99.9% @m=.15", math.ceil(math.log(1e-3)/math.log(m)), 4, ok(math.ceil(math.log(1e-3)/math.log(m))==4)))

# ---------- 6. void accounting
gross = 100*2*2.8; debris = gross*1.35
for vf, want_v, want_cells in [(0.05,37.8,15.1),(0.08,60.5,24.2),(0.12,90.7,36.3)]:
    v = debris*vf
    rows.append((f"void m3 @{int(vf*100)}%", round(v,1), want_v, ok(abs(v-want_v)<.1)))
    rows.append((f"cells @{int(vf*100)}%", round(v/2.5,1), want_cells, ok(abs(v/2.5-want_cells)<.1)))
rows.append(("compression log10 (1km2x100m -> 60.5)", round(math.log10(1e6*100/60.5),1), 6.2,
             ok(abs(math.log10(1e6*100/60.5)-6.2)<.05)))

# ---------- 7. thermal
NETD, CL, TAU = 0.05, 0.30, 0.55
def snr(dT, fill): return dT*TAU*fill/math.sqrt(NETD**2+CL**2)
for t, want in [(0,7.96),(20,4.42),(40,2.45)]:
    dT = (34-26)*math.exp(-t/34.0); got = snr(dT,0.55)
    rows.append((f"thermal SNR exposed t={t}min", round(got,2), want, ok(abs(got-want)<.03)))
blind = next(t for t in range(0,241) if snr((34-26)*math.exp(-t/34.0),0.55) < 4)
rows.append(("minutes to blind (exposed)", blind, 24, ok(blind in (22,24,26))))
rows.append(("head-only blind at t=0?", snr(8,0.06) < 4, True, ok(snr(8,0.06)<4)))

# ---------- 8. RF depths
for band,budget,att,want in [("BLE 2.4GHz",95,150,0.63),("LoRa 865",151,55,2.75),
                             ("UWB 0.5-2.25",60,80,0.75),("UWB 3-5GHz",60,140,0.43)]:
    got = budget/att
    rows.append((f"{band} depth wet rubble", round(got,2), want, ok(abs(got-want)<.02)))

# ---------- 9. skin depth
for f,want in [(866e6,0.171),(2.4e9,0.103)]:
    got = 1/math.sqrt(math.pi*f*4*math.pi*1e-7*0.01)
    rows.append((f"skin depth {int(f/1e6)}MHz", round(got,3), want, ok(abs(got-want)<.004)))

# ---------- 10. drone swath
for alt,want_sw,want_ha in [(30,17.2,10.98),(60,34.4,21.97),(120,68.8,43.93)]:
    sw = 2*alt*math.tan(math.radians(32)/2)
    area = sw*0.7*8*(25-6)*60
    rows.append((f"swath @{alt}m", round(sw,1), want_sw, ok(abs(sw-want_sw)<.1)))
    rows.append((f"ha/sortie @{alt}m", round(area/1e4,2), want_ha, ok(abs(area/1e4-want_ha)<.05)))

# ---------- 11. cost model
for p,want in [(0.33,402),(0.99,6)]:
    tp=50*p; fp=50-tp
    rows.append((f"team-min wasted @PPV {p}", round(fp*12), want, ok(abs(fp*12-want)<2)))

# ---------- 12. survival curve fit
def surv(t): return math.exp(-((t/60.4)**2.5))
for t,lo,hi in [(24,.74,.91),(48,.50,.57),(72,.20,.30)]:
    rows.append((f"survival @{t}h in range", round(surv(t),3), f"{lo}-{hi}", ok(lo<=surv(t)<=hi)))

# ---------- 13. GSD / recognition limit
m_per_px = (2*30*math.tan(math.radians(16)))/640
rows.append(("thermal cm/px @30m", round(m_per_px*100,1), 2.7, ok(abs(m_per_px*100-2.7)<.05)))
rec = (0.5/8*640)/(2*math.tan(math.radians(16)))
rows.append(("recognition limit m (8px, 0.5m)", round(rec,1), 69.7, ok(abs(rec-69.7)<.5)))

passes = sum(1 for r in rows if r[3]=="PASS")
print(f"{'claim':46s} {'computed':>12s} {'stated':>10s}  result")
print("-"*90)
for n,g,w,r in rows:
    print(f"{n:46s} {str(g):>12s} {str(w):>10s}  {r}")
print("-"*90)
print(f"{passes}/{len(rows)} verified")
