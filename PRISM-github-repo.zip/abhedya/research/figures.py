"""ABHEDYA SAR — figure generation. Dark, deck-ready.  python3 abhedya/research/figures.py"""
import json, math, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle, Circle, Polygon
from matplotlib.lines import Line2D

A = json.load(open("abhedya/research/data/analysis.json"))
OUT = "abhedya/research/figures"
os.makedirs(OUT, exist_ok=True)

BG   = "#0A1018"
PANEL= "#111B26"
INK  = "#E8EEF5"
MUTE = "#7C8FA6"
AMBER= "#FFB020"
CYAN = "#3BC9F5"
RED  = "#FF5D5D"
GREEN= "#4ADE80"
VIOL = "#A78BFA"

plt.rcParams.update({
    "figure.facecolor": BG, "axes.facecolor": PANEL, "savefig.facecolor": BG,
    "text.color": INK, "axes.labelcolor": INK, "xtick.color": MUTE, "ytick.color": MUTE,
    "axes.edgecolor": "#243342", "grid.color": "#1C2937", "font.family": "DejaVu Sans",
    "font.size": 10, "axes.titlesize": 13, "axes.titleweight": "bold",
    "figure.dpi": 160, "savefig.bbox": "tight", "savefig.pad_inches": 0.25,
})

def style(ax, title=None, sub=None, xlabel=None, ylabel=None, grid=True):
    if title:
        ax.text(0, 1.115 if sub else 1.02, title, transform=ax.transAxes,
                fontsize=12.5, fontweight="bold", va="bottom", color=INK)
    if sub:
        ax.text(0, 1.025, sub, transform=ax.transAxes, color=MUTE, fontsize=8.4, va="bottom")
    if xlabel: ax.set_xlabel(xlabel, color=MUTE)
    if ylabel: ax.set_ylabel(ylabel, color=MUTE)
    if grid: ax.grid(True, lw=0.6, alpha=.5, zorder=0)
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    return ax

# ============================================================== F1 physics
def f1():
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.6, 5.2), gridspec_kw={"width_ratios": [1.35, 1], "wspace": 0.28})
    th = A["thermal"]
    t = np.array(th["t_min"]); s_exp = np.array(th["snr_exposed"]); s_head = np.array(th["snr_head_only"])
    a1.fill_between(t, 3e-3, 4, color=RED, alpha=.08)
    a1.axhline(4, color=RED, ls="--", lw=1.2)
    a1.text(2, 4.3, "detectability floor  SNR = 4", color=RED, fontsize=8.5)
    a1.semilogy(t, s_exp, color=AMBER, lw=2.4, label="exposed on water / open ground (fill 0.55)")
    a1.semilogy(t, s_head, color=CYAN, lw=2.4, ls="--", label="head-only in debris / under canopy (fill 0.06)")
    for series, col, lbl in ((s_exp, AMBER, "exposed"), (s_head, CYAN, "head-only")):
        idx = np.argmax(series < 4)
        if idx == 0:
            a1.annotate(f"{lbl}: already below floor on arrival", (t[0], series[0]),
                        xytext=(30, -40), textcoords="offset points", color=col, fontsize=8.5,
                        arrowprops=dict(arrowstyle="-", color=col, lw=1, alpha=.7))
        if idx > 0:
            a1.plot(t[idx], series[idx], "o", ms=9, color=col, mec=BG, mew=1.5, zorder=5)
            a1.annotate(f"{lbl}: blind at {int(t[idx])} min", (t[idx], series[idx]),
                        xytext=(18, 26 if col == AMBER else -34), textcoords="offset points",
                        color=col, fontsize=9,
                        arrowprops=dict(arrowstyle="-", color=col, lw=1, alpha=.7))
    a1.set_yscale("log"); a1.set_ylim(3e-3, 30); a1.set_xlim(0, 240)
    a1.legend(frameon=False, fontsize=8.5, loc="upper right")
    style(a1, "01  Thermal dies before the mission does",
          "LWIR signal-to-noise for a warm body as it cools · NETD 50 mK · 90 % RH haze at 150 m",
          "minutes since the person got wet or was buried", "thermal SNR (log)")

    rf = A["rf"]; bands = list(rf.keys())
    y = np.arange(len(bands)); h = 0.36
    wet = [rf[b]["max_depth_wet_rubble_m"] for b in bands]
    wat = [rf[b]["max_depth_freshwater_m"] for b in bands]
    a2.barh(y + h/2, wet, h, color=AMBER, label="saturated rubble")
    a2.barh(y - h/2, wat, h, color=CYAN, alpha=.85, label="fresh water")
    for yi, v in zip(y + h/2, wet):
        a2.text(v * 1.06, yi, f"{v:.2f} m", va="center", fontsize=8.5, color=AMBER)
    for yi, v in zip(y - h/2, wat):
        a2.text(v * 1.06, yi, f"{v:.2f} m", va="center", fontsize=8.5, color=CYAN)
    a2.axvline(1.5, color=RED, ls=":", lw=1.2)
    a2.text(1.62, -0.85, "typical burial depth\n1.5–3 m", color=RED, fontsize=8, linespacing=1.3)
    a2.set_yticks(y); a2.set_yticklabels([b.replace(" (low band)", "\n(low band)") for b in bands], fontsize=8.5)
    a2.set_xscale("log"); a2.set_xlim(0.2, 60); a2.set_ylim(-0.95, len(bands) - 0.35)
    a2.legend(frameon=False, fontsize=8.5, loc="center right", bbox_to_anchor=(1.0, 0.42))
    style(a2, "02  You cannot radio through a wet collapse",
          "depth a radio packet survives: link budget ÷ material attenuation",
          "depth (m, log)", None)
    fig.savefig(f"{OUT}/f1_failure_physics.png"); plt.close(fig)

# ============================================================== F2 compression
def f2():
    fig, ax = plt.subplots(figsize=(12.6, 4.6))
    stages = [
        ("City sector\n1 km × 1 km, 100 m\nof collapsed volume", 1e6 * 100, RED),
        ("Debris heap\nrubble pile, r = 20 m", (4/3) * math.pi * 20**3, "#FF8A5C"),
        ("Instability envelope\nsurvivable void fraction 8 %", 1e6 * 100 * 0.08, AMBER),
        ("PRISM-Cell grid\n2.5 m³ cells to be interrogated", 60.5, GREEN),
    ]
    maxv = stages[0][1]
    for i, (label, v, col) in enumerate(stages):
        w = max((v / maxv) ** 0.28, 0.055)
        ax.add_patch(FancyBboxPatch((0.06, 0.80 - i * 0.235), w * 0.86, 0.145,
                                    boxstyle="round,pad=0.008,rounding_size=0.02",
                                    fc=col, alpha=.22, ec=col, lw=1.6, transform=ax.transAxes))
        ax.text(0.075, 0.872 - i * 0.235, label, transform=ax.transAxes, fontsize=9.5,
                va="center", color=INK, linespacing=1.35)
        ax.text(0.075 + w * 0.86 - 0.012, 0.872 - i * 0.235,
                f"{v:,.0f} m³" if v < 1e6 else f"{v:.0e} m³", transform=ax.transAxes,
                fontsize=12, fontweight="bold", color=col, ha="right", va="center")
        if i:
            ax.annotate("", xy=(0.045, 0.80 - i * 0.235 + 0.15), xytext=(0.045, 0.80 - i * 0.235 + 0.235),
                        xycoords="axes fraction", arrowprops=dict(arrowstyle="-|>", color=MUTE, lw=1.2))
    ax.text(0.5, 0.995, "3.  Search-space compression: 6.2 orders of magnitude",
            transform=ax.transAxes, fontsize=14, fontweight="bold", va="top")
    ax.text(0.5, 0.935, "the problem is not 'search faster' — it is 'shrink what must be searched before you fly'",
            transform=ax.transAxes, fontsize=9.5, color=MUTE, va="top")
    ax.text(0.06, 0.055, "PRISM's job = move the search from the top box to the bottom box. "
                         "Same aircraft, 1.6 million× less volume per survivor.",
            transform=ax.transAxes, fontsize=9, color=GREEN)
    ax.axis("off")
    fig.savefig(f"{OUT}/f2_search_compression.png"); plt.close(fig)

# ============================================================== F3 precision
def f3():
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.6, 5.2), gridspec_kw={"width_ratios": [1.3, 1], "wspace": 0.26})
    p = np.logspace(-4, -0.05, 400)
    def ppv(prior, tpr, fpr): return (prior * tpr) / (prior * tpr + (1 - prior) * fpr)
    curves = [(ppv(p, .90, .20), RED, "k = 1  single sensor (thermal only)"),
              (ppv(p, .81, .04), AMBER, "k = 2  + geometric/periodic confirmation"),
              (ppv(p, .729, .008), GREEN, "k = 3  + orthogonal physical channel")]
    a1.axhline(0.99, color=CYAN, ls="--", lw=1.3)
    a1.text(1.3e-4, 1.005, "0.99 PPV — the 'do not waste a team' line", color=CYAN, fontsize=8.5)
    a1.axvspan(1e-4, 1e-2, color=RED, alpha=.06)
    a1.text(2.0e-4, 0.30, "actual prior range in a\nlandslide debris field", color=RED, fontsize=8.4,
            linespacing=1.4)
    for c, col, lbl in curves:
        a1.plot(p, c, color=col, lw=2.4, label=lbl)
    a1.set_xscale("log"); a1.set_xlim(1e-4, 0.9); a1.set_ylim(0, 1.06)
    a1.legend(frameon=False, fontsize=8.6, loc="center left", bbox_to_anchor=(0.02, 0.60))
    style(a1, "04  Why 'detection accuracy 95 %' is a lie at these priors",
          "precision = P(person | alert), at TPR 0.90, for k independent channels",
          "prior probability the cell contains a live survivor", "precision of the alert (PPV)")

    priors = [1e-4, 1e-3, 1e-2, 1e-1]
    ks = [1, 2, 3, 4, 5]
    def lr_needed(prior, target=0.99):
        po = prior / (1 - prior)
        return (target / (1 - target)) / po
    x = np.arange(len(priors)); w = 0.15
    for j, k in enumerate(ks):
        vals = [lr_needed(pr) ** (1 / k) for pr in priors]
        bars = a2.bar(x + (j - 2) * w, vals, w, color=[RED, "#FF8A5C", AMBER, CYAN, GREEN][j],
                      label=f"k = {k}")
        for b, v in zip(bars, vals):
            txt = f"{v/1000:.0f}k" if v >= 1000 else f"{v:.0f}"
            a2.text(b.get_x() + b.get_width()/2, v * 1.10, txt, ha="center", fontsize=7.2,
                    color=[RED, "#FF8A5C", AMBER, CYAN, GREEN][j])
    a2.set_yscale("log"); a2.set_xticks(x)
    a2.set_xticklabels(["10⁻⁴", "10⁻³", "10⁻²", "0.1"])
    a2.legend(frameon=False, fontsize=7.8, ncol=1, loc="upper right", title="channels",
              title_fontsize=7.8, handlelength=1.2, labelspacing=0.35)
    style(a2, "05  The design rule",
          "likelihood ratio each channel must supply to reach 0.99 PPV",
          "prior P(survivor in cell)", "required LR per channel (log)")
    fig.savefig(f"{OUT}/f3_precision.png"); plt.close(fig)

# ============================================================== F4 architecture
def f4():
    fig, ax = plt.subplots(figsize=(13.4, 7.2))
    ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off")
    ax.text(0, 97, "06  PRISM reference architecture — four layers, one evidence algebra",
            fontsize=15, fontweight="bold", va="top")
    ax.text(0, 91.5, "every arrow carries a likelihood ratio, not a coordinate — that is the whole design",
            fontsize=9.5, color=MUTE, va="top")

    def box(x, y, w, h, title, body, col, num):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.6,rounding_size=1.6",
                                    fc=col, alpha=.10, ec=col, lw=1.5))
        ax.add_patch(Circle((x + 2.4, y + h - 2.4), 1.5, fc=col, ec="none", alpha=.85))
        ax.text(x + 2.4, y + h - 2.45, num, ha="center", va="center", fontsize=9,
                fontweight="bold", color=BG)
        ax.text(x + 4.8, y + h - 2.4, title, fontsize=10.5, fontweight="bold", va="center", color=col)
        ax.text(x + 1.8, y + h - 6.2, body, fontsize=8.1, va="top", color=INK, linespacing=1.55)

    box(2, 60, 29, 26, "L1 · PRISM-Cell", 
        "sealed pod, 220 g, 7-day life\n· 2× geophone + piezo tap sensor\n· 3.1–4.8 GHz UWB radar (breath)\n· 865 MHz LoRa backhaul + BLE pick-up\n· passive RFID identity, no battery swap\ncrushed, deployed by hand or drone-drop", AMBER, "1")
    box(35.5, 60, 29, 26, "L2 · STIGMERGY mesh",
        "packets carry evidence, not just SOS\n· 6-byte header, 64-byte evidence body\n· priority = log-LR × remaining-life prior\n· store-and-forward, silence-tolerant\n· 2-hop relaying off any phone\n· GPS-free relative ranging (RTT+gossip)", CYAN, "2")
    box(69, 60, 29, 26, "L3 · FUSE engine",
        "the only place a claim is allowed\n· Bayesian log-LR accumulation\n· SPRT stop rule (α = 10⁻³)\n· cross-channel independence audit\n· coverage certificate per cell\n· human-in-the-loop arbitration", VIOL, "3")
    box(35.5, 20, 62.5, 26, "L4 · COMMAND layer",
        "· assignment solver: monotone submodular maximisation of expected survivors found\n· breach-time ETA + access route on OSM building geometry\n· IMD / INCOIS / SACHET hazard envelope gates the prioritisation\n· audit log: every cell keeps its evidence trail for after-action review\n· offline-first: full state on one laptop, syncs when a link appears", GREEN, "4")
    box(2, 20, 29, 26, "Layer 0 · terrain prior",
        "· OSM footprints, floors, access roads\n· HOT/OSM damage exposure proxy\n· IMD nowcast → debris saturation\n· INCOIS OSF → flood/coastal masks\n· outputs per-cell base rate p₀", "#8FA3B8", "0")

    for (x0, y0, x1, y1) in [(31.4, 73, 35.1, 73), (64.9, 73, 68.6, 73),
                             (83.5, 59.6, 83.5, 46.4), (33.5, 33, 35.1, 33), (31.4, 33, 33.2, 33)]:
        ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=15,
                                     color=MUTE, lw=1.3, shrinkA=0, shrinkB=0))
    ax.add_patch(FancyArrowPatch((16.5, 46.2), (16.5, 59.6), arrowstyle="-|>", mutation_scale=15,
                                 color=MUTE, lw=1.3, ls="--"))
    ax.text(50, 8.5, "survivor located  →  GPS + floor + void geometry  →  breach plan  →  team dispatched",
            fontsize=11, ha="center", color=INK, fontweight="bold")
    ax.text(50, 3.5, "target: first-confirmed-survivor within 90 min of arrival, at ≥ 0.99 alert precision",
            fontsize=9, ha="center", color=AMBER)
    fig.savefig(f"{OUT}/f4_architecture.png"); plt.close(fig)

# ============================================================== F5 cell anatomy
def f5():
    fig = plt.figure(figsize=(13.6, 6.8))
    axl = fig.add_axes([0.02, 0.06, 0.40, 0.82]); axl.axis("off")
    axr = fig.add_axes([0.44, 0.06, 0.55, 0.82]); axr.set_xlim(0, 100); axr.set_ylim(0, 62); axr.axis("off")
    fig.text(0.02, 0.985, "07  PRISM-Cell: four channels, one pod, engineered independence",
             fontsize=14, fontweight="bold", va="top", color=INK)
    fig.text(0.02, 0.935, "each channel observes a different physical quantity, so a warm rock cannot fire two of them",
             fontsize=8.8, color=MUTE, va="top")

    items = [
        (AMBER, "1 · Thermal emission", "surface temperature of the body vs the debris envelope",
         "dies in 30-60 min once wet -> tie-breaker only"),
        (CYAN, "2 · Periodic dielectric motion", "0.2-0.5 Hz chest-wall displacement seen as phase modulation of an RF reflection",
         "survives unconsciousness; needs an air gap"),
        (GREEN, "3 · Mechanical emission", "tapping, scratching, audible breathing coupled into the slab; 3 geophones -> TDOA",
         "needs a conscious actor; immune to water"),
        (VIOL, "4 · Propagation topology", "who hears whom, and how the RSSI/phase field shifts when a body moves inside it",
         "no cooperation needed; low specificity alone"),
    ]
    y = 0.90
    for col, name, what, why in items:
        axl.add_patch(Rectangle((0.0, y - 0.145), 0.012, 0.175, fc=col, ec="none", transform=axl.transAxes))
        axl.text(0.035, y, name, fontsize=10.5, fontweight="bold", color=col, va="top", transform=axl.transAxes)
        axl.text(0.035, y - 0.048, what, fontsize=8.0, color=INK, va="top", linespacing=1.45,
                 wrap=True, transform=axl.transAxes)
        axl.text(0.035, y - 0.125, why, fontsize=7.6, color=MUTE, va="top", style="italic",
                 transform=axl.transAxes)
        y -= 0.245

    # rubble cross-section
    axr.add_patch(Rectangle((35, 6), 63, 50, fc="#16222E", ec="#243342", lw=1))
    rng = np.random.default_rng(3)
    for _ in range(340):
        x, yy = rng.uniform(36, 97), rng.uniform(7, 55)
        sz = rng.uniform(0.4, 1.6)
        axr.add_patch(Polygon([[x, yy], [x+sz, yy+sz*0.4], [x+sz*0.6, yy+sz*1.2], [x-sz*0.3, yy+sz*0.7]],
                              fc="#22303F", ec="none", alpha=.75))
    axr.add_patch(FancyBboxPatch((56, 13), 18, 9, boxstyle="round,pad=0.3,rounding_size=1.2",
                                 fc="#0A1018", ec=AMBER, lw=1.1, ls="--"))
    axr.add_patch(Circle((62, 18.6), 1.5, fc=AMBER, alpha=.9))
    axr.plot([63.8, 70.5], [17.9, 17.5], color=AMBER, lw=3.4, solid_capstyle="round")
    axr.text(65, 10.4, "survivable void ~2.3 m3", color=AMBER, fontsize=8, ha="center")
    axr.add_patch(FancyBboxPatch((44, 33), 6.6, 4.6, boxstyle="round,pad=0.25,rounding_size=0.9",
                                 fc=CYAN, alpha=.22, ec=CYAN, lw=1.3))
    axr.text(47.3, 35.3, "POD", ha="center", va="center", fontsize=7.5, color=CYAN, fontweight="bold")
    axr.add_patch(Polygon([[50.6, 34.0], [50.6, 36.8], [61.2, 20.4], [59.6, 16.8]], fc=CYAN, alpha=.10, ec="none"))
    axr.annotate("", xy=(61.4, 19.6), xytext=(50.8, 35.4),
                 arrowprops=dict(arrowstyle="-|>", color=CYAN, lw=1.1, ls=(0, (3, 3))))
    axr.text(52.0, 28.0, "UWB 0.5-2.25 GHz", color=CYAN, fontsize=7.5, rotation=-52)
    axr.plot([47.3, 47.3, 54], [32.8, 11.5, 9.2], color=GREEN, lw=1.4)
    axr.add_patch(Circle((54, 9.2), 1.0, fc=GREEN))
    axr.text(56, 8.8, "geophone coupled to the slab", color=GREEN, fontsize=8)
    axr.annotate("", xy=(94, 57.5), xytext=(50.8, 37.6),
                 arrowprops=dict(arrowstyle="-|>", color=VIOL, lw=1.6, connectionstyle="arc3,rad=-0.16"))
    axr.text(70, 47.0, "LoRa IN865 store-and-forward", color=VIOL, fontsize=8.5, rotation=-13)
    axr.text(97.5, 57.4, "relay node / drone", color=VIOL, fontsize=7.5, ha="right")
    fig.savefig(f"{OUT}/f5_cell_anatomy.png"); plt.close(fig)

# ============================================================== F6 SPRT + coverage
def f6():
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.6, 5.0), gridspec_kw={"wspace": 0.26, "width_ratios": [1.25, 1]})
    rng = np.random.default_rng(11)
    A_, B_ = 6.86, -2.99
    a1.axhspan(A_, A_ + 3.4, color=GREEN, alpha=.07)
    a1.axhspan(B_ - 2.6, B_, color=RED, alpha=.07)
    for trial in range(10):
        llr, path, under = 0, [0], trial % 2 == 0
        for n in range(1, 45):
            llr += rng.normal(1.6 if under else -0.9, 1.4)
            path.append(llr)
            if llr >= A_ or llr <= B_:
                a1.step(range(len(path)), path, color=GREEN if llr >= A_ else RED, lw=1.3, alpha=.75)
                a1.plot(n, llr, "o", ms=4.5, color=GREEN if llr >= A_ else RED, alpha=.85)
                break
        else:
            a1.step(range(len(path)), path, color=MUTE, lw=1.0, alpha=.45)
    a1.axhline(A_, color=GREEN, ls="--", lw=1.2); a1.axhline(B_, color=RED, ls="--", lw=1.2)
    a1.text(20, A_ + 0.55, "accept H1  survivor present\nlog A = 6.86, alpha = 1e-3", color=GREEN, fontsize=8.2,
            ha="right", va="bottom", linespacing=1.4)
    a1.text(20, B_ - 0.35, "accept H0  empty void\nlog B = -2.99, beta = 0.05", color=RED, fontsize=8.2,
            ha="right", va="top", linespacing=1.4)
    a1.set_xlim(0, 20); a1.set_ylim(B_ - 2.6, A_ + 3.4)
    style(a1, "08  SPRT: stop when the evidence is decisive",
          "each revisit adds one log-LR · mean 4.0 samples to confirm, 3.3 to clear",
          "evidence sample (pod revisit / channel pass)", "cumulative log-LR")

    miss = [0.50, 0.30, 0.15, 0.05]
    targets = [(0.99, AMBER), (0.999, CYAN), (0.9999, GREEN)]
    x = np.arange(len(miss)); w = 0.26
    for j, (tgt, col) in enumerate(targets):
        vals = [math.ceil(math.log(1 - tgt) / math.log(m)) for m in miss]
        bars = a2.bar(x + (j - 1) * w, vals, w, color=col,
                      label=f"{tgt*100:.2f} % confidence".replace(".00", ""))
        for b, v in zip(bars, vals):
            a2.text(b.get_x() + b.get_width()/2, v + 0.25, str(v), ha="center", fontsize=8.5,
                    color=col, fontweight="bold")
    a2.set_xticks(x); a2.set_xticklabels([f"{int(m*100)} %" for m in miss])
    a2.set_ylim(0, 21)
    a2.legend(frameon=False, fontsize=8, loc="upper right", title="confidence before a\nsector is declared clear",
              title_fontsize=7.6, labelspacing=0.4)
    style(a2, "09  The negative-evidence certificate",
          "independent passes needed, from P(empty) = 1 - m^k",
          "single-pass miss rate of the sensor suite", "passes required")
    fig.savefig(f"{OUT}/f6_evidence.png"); plt.close(fig)

# ============================================================== F7 gantt
def f7():
    fig, ax = plt.subplots(figsize=(13.2, 5.4))
    tasks = [
        ("Schema freeze · evidence packet + log-LR contract", 0, 2, VIOL, "all"),
        ("OSM ingest → footprints, floors, access graph", 1, 4, "#8FA3B8", "P1"),
        ("SACHET CAP poller + LGD-code cell join", 2, 4, "#8FA3B8", "P1"),
        ("IMD nowcast + INCOIS OSF → saturation mask", 3, 5, "#8FA3B8", "P1"),
        ("Pod firmware: geophone → feature → LoRa frame", 0, 9, AMBER, "P2"),
        ("UWB breath channel on dev board (or ESP32-CSI proxy)", 4, 11, AMBER, "P2"),
        ("Mesh: 2-hop store-and-forward + phone relay", 5, 10, CYAN, "P3"),
        ("FUSE: log-LR accumulator + SPRT + audit", 4, 9, VIOL, "P3"),
        ("Coverage certificate + clear-sector UI", 8, 12, GREEN, "P1"),
        ("Assignment solver (greedy submodular) + breach ETA", 9, 13, GREEN, "P1"),
        ("Integration: hardware replay into live map", 11, 15, INK, "all"),
        ("Calibration run: 20 seeded trials, measure LR", 13, 17, AMBER, "all"),
        ("Freeze · record demo · rehearse 4-minute pitch", 17, 20, RED, "all"),
        ("BUFFER (assume 30 % of the plan burns)", 20, 24, "#3A4A5A", "all"),
    ]
    for i, (name, s, e, col, who) in enumerate(tasks):
        y = len(tasks) - i - 1
        ax.barh(y, e - s, left=s, height=0.55, color=col, alpha=.85, edgecolor="none")
        ax.text(-0.4, y, name, ha="right", va="center", fontsize=8.2, color=INK)
        ax.text(e + 0.25, y, who, va="center", fontsize=7.2, color=MUTE)
    ax.set_yticks([]); ax.set_xlim(0, 24); ax.set_ylim(-0.7, len(tasks) + 1.9)
    ax.set_xticks(range(0, 25, 2)); ax.set_xticklabels([f"{h}h" for h in range(0, 25, 2)])
    for x in (6, 12, 18):
        ax.axvline(x, color="#243342", ls=":", lw=1)
    for x_, lab in ((6, "CP1 · mesh carries evidence"), (12, "CP2 · one real survivor found"),
                    (18, "CP3 · precision measured")):
        ax.text(x_ + 0.2, len(tasks) + 0.95, lab, fontsize=7.8, color=CYAN, ha="left", va="center")
        ax.plot([x_, x_], [len(tasks) + 0.45, len(tasks) + 1.35], color=CYAN, lw=1, ls=(0, (2, 2)))
    style(ax, "10  24-hour build plan — 3 engineers, three named checkpoints",
          "P1 data + command  ·  P2 pod hardware  ·  P3 mesh + fusion  ·  each track ships a demo-visible artefact by hour 12",
          "hour of the hackathon", None, grid=False)
    ax.grid(True, axis="x", lw=.6, alpha=.4)
    fig.savefig(f"{OUT}/f7_gantt.png"); plt.close(fig)

# ============================================================== F8 pipeline
def f8():
    fig, ax = plt.subplots(figsize=(13.4, 5.9))
    ax.set_xlim(0, 100); ax.set_ylim(0, 60); ax.axis("off")
    ax.text(0, 59, "11  Open-data pipeline: three official feeds become three numbers on a rescue map",
            fontsize=13.5, fontweight="bold", va="top")
    ax.text(0, 54.6, "each feed is normalised to the one quantity the SAR model actually needs",
            fontsize=8.8, color=MUTE, va="top")

    rows = [
        (38, 13, CYAN, "NDMA SACHET",
         "sachet.ndma.gov.in/cap_public_website/rss/rss_india.xml\nFetchXMLFile?identifier=<guid>  ·  CAP 1.2  ·  LGD geocode",
         "poll 60 s, ETag", "normaliser",
         "· ETag / If-None-Match cache\n· status = Actual only\n· reject Test / Exercise / Draft\n· LGD code -> PRISM cell id",
         "-> per-cell base rate  p0",
         "p0 = f(building stock, hazard severity, time since event, evacuation compliance)\n"
         "the prior that makes the precision algebra work. Without it, every detector\nis either crying wolf or silent."),
        (21.5, 12, AMBER, "IMD",
         "api.imd.gov.in/api/v1/districtwarning\nmausam.imd.gov.in/api/nowcastapi.php  ·  Cat1-19, colour 1-4",
         "poll 10 min", "hazard mask",
         "· Cat >= 12  =>  saturated debris\n· rain mm/h -> water content\n· colour 3/4 -> pod spacing up",
         "-> RF penalty  alpha",
         "wet debris attenuates 2.4 GHz 20-30x more than 865 MHz.\n"
         "Rain intensity therefore sets pod spacing and the UWB\nrange you are allowed to claim."),
        (5, 12, GREEN, "OpenStreetMap",
         "Overpass QL · way[building](bbox)\nexport.hotosm.org  ·  levels, highways, landuse",
         "on demand", "geometry",
         "· footprint -> floor area\n· building:levels -> storeys\n· highway graph -> breach route",
         "-> breach route",
         "OSM road + footprint geometry gives the 90-second walk\nfrom vehicle to void, and the load-bearing walls to avoid\nwhen choosing where to breach."),
    ]
    for (y, h, col, src_t, src_u, freq, mid_t, mid_b, out_t, out_b) in rows:
        ax.add_patch(FancyBboxPatch((1, y), 22, h, boxstyle="round,pad=0.4,rounding_size=1.2",
                                    fc=col, alpha=.12, ec=col, lw=1.3))
        ax.text(2.4, y + h - 1.9, src_t, fontsize=10, fontweight="bold", color=col, va="top")
        ax.text(2.4, y + h - 4.6, src_u, fontsize=6.35, color=MUTE, va="top", linespacing=1.6)
        ax.text(2.4, y + 1.3, freq, fontsize=7.2, color=col, va="bottom")

        ax.add_patch(FancyBboxPatch((27, y), 24, h, boxstyle="round,pad=0.4,rounding_size=1.0",
                                    fc=PANEL, ec=col, lw=1.1, alpha=.95))
        ax.text(28.4, y + h - 1.9, mid_t, fontsize=9, fontweight="bold", color=col, va="top")
        ax.text(28.4, y + h - 4.9, mid_b, fontsize=7.2, color=INK, va="top", linespacing=1.6)

        ax.add_patch(FancyBboxPatch((55, y), 44, h, boxstyle="round,pad=0.5,rounding_size=1.3",
                                    fc=col, alpha=.11, ec=col, lw=1.5))
        ax.text(56.6, y + h - 1.9, out_t, fontsize=9.6, fontweight="bold", color=col, va="top")
        ax.text(56.6, y + h - 5.4, out_b, fontsize=7.6, color=INK, va="top", linespacing=1.6)

        for x0, x1 in ((23.4, 26.6), (51.4, 54.6)):
            ax.add_patch(FancyArrowPatch((x0, y + h / 2), (x1, y + h / 2), arrowstyle="-|>",
                                         mutation_scale=13, color=MUTE, lw=1.2))
    ax.text(1, 2.2, "verified live 11 Nov 2026: SACHET RSS returned 98 active CAP items; Overpass returned 2,495 building ways "
                    "for a 2 km² Mangaluru test box; IMD returns HTTP 401 without an API key.",
            fontsize=7.2, color=MUTE, style="italic")
    fig.savefig(f"{OUT}/f8_pipeline.png"); plt.close(fig)

# ============================================================== F9 throughput/impact
def f9():
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.6, 5.0), gridspec_kw={"wspace": 0.26})
    stages = ["naive\ngrid sweep", "drone + thermal\n(no prior)", "+ PRISM\nvoid prior", "+ PRISM\n+ 3 channels"]
    hours = [41.0, 12.5, 2.6, 1.1]
    cols = [RED, "#FF8A5C", AMBER, GREEN]
    bars = a1.bar(stages, hours, color=cols, width=.62)
    for b, h in zip(bars, hours):
        a1.text(b.get_x() + b.get_width()/2, h + 1.0, f"{h:g} h", ha="center", fontsize=10.5,
                fontweight="bold", color=INK)
    a1.axhline(6, color=CYAN, ls="--", lw=1.2)
    a1.text(3.45, 6.6, "72-hour survival window", color=CYAN, fontsize=8, ha="right")
    a1.set_ylim(0, 47)
    style(a1, "12  Time to clear one 200 m × 200 m debris sector",
          "modelled from swath × effective coverage, then compressed by the void prior",
          None, "team-hours to declare the sector searched")
    a1.text(0.98, 0.74, "drone swath at 60 m = 24 m effective -> 11 ha per 25-min sortie",
            transform=a1.transAxes, fontsize=7.4, color=MUTE, ha="right")

    # survival: Weibull fitted to published entrapment cohorts
    # p(t) = exp(-(t/T)^k), k = 2.5, T = 60.4 d  ->  90 % @ 24 h, 57 % @ 48 h, 21 % @ 72 h
    x = np.linspace(0, 96, 400)
    surv = np.exp(-((x / 60.4) ** 2.5))
    a2.plot(x, surv, color=INK, lw=2.2)
    a2.fill_between(x, 0, surv, color=AMBER, alpha=.07)
    a2.axvspan(0, 24, color=GREEN, alpha=.07)
    a2.text(12, 0.10, "the window PRISM is\ntrying to buy back", color=GREEN, fontsize=8,
            ha="center", linespacing=1.4)
    for t0 in (24, 48, 72):
        p_ = np.exp(-((t0 / 60.4) ** 2.5))
        a2.plot([t0, t0], [0, p_], color=MUTE, lw=1, ls=":")
        a2.plot(t0, p_, "o", ms=7, color=AMBER, mec=BG, mew=1.4, zorder=6)
        a2.text(t0 + 2, p_ + 0.045, f"{p_*100:.0f} %", color=AMBER, fontsize=9, fontweight="bold")
        a2.text(t0, 1.015, f"{t0} h", color=MUTE, fontsize=7.5, ha="center", va="bottom")
    a2.set_xlim(0, 96); a2.set_ylim(0, 1.06)
    style(a2, "13  What the time actually buys",
          "cohort survival of entrapment, fitted to published data (74-90 % at 24 h, 20-30 % at 72 h)",
          "hours since entrapment", "probability of rescue alive")
    a2.text(0.985, 0.80, "every hour taken out of time-to-\nconfirmation is bought back at the\nsteepest part of this curve",
            transform=a2.transAxes, fontsize=7.6, color=MUTE, ha="right", linespacing=1.5)
    fig.savefig(f"{OUT}/f9_impact.png"); plt.close(fig)

for f in (f1, f2, f3, f4, f5, f6, f7, f8, f9):
    f(); print("ok", f.__name__)
