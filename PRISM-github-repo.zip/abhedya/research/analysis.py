"""
ABHEDYA SAR — engineering analysis harness (v2, calibrated).
Every number quoted in the dossier / pitch deck / judge appendix is computed here.
Run: python3 abhedya/research/analysis.py
"""
import json, math, os
import numpy as np

OUT = {}
os.makedirs("abhedya/research/data", exist_ok=True)
os.makedirs("abhedya/research/figures", exist_ok=True)

# ============================================================ 1. OPTICS
def gsd(sensor_px, hfov_deg, altitude_m):
    ground_width = 2 * altitude_m * math.tan(math.radians(hfov_deg) / 2)
    m_per_px = ground_width / sensor_px
    return m_per_px * 100, 0.5 / m_per_px, 1.0 / m_per_px   # cm/px, px on 0.5m & 1.0m dim

def alt_for_px(px_on_target, critical_dim_m, sensor_px, hfov_deg):
    m_per_px = critical_dim_m / px_on_target
    return (m_per_px * sensor_px) / (2 * math.tan(math.radians(hfov_deg) / 2))

optics = []
for alt_m in (15, 30, 60, 120):
    t = gsd(640, 32, alt_m)    # 640x512 LWIR, 32 deg HFOV (M30T-class)
    v = gsd(4000, 73, alt_m)   # 12 MP visible, 73 deg HFOV
    optics.append(dict(alt_m=alt_m, alt_ft=round(alt_m * 3.281),
                       thermal_cm_px=round(t[0], 1), thermal_px_short=round(t[1], 1),
                       thermal_px_long=round(t[2], 1), rgb_cm_px=round(v[0], 1)))
OUT["gsd"] = optics
# Johnson criteria: 2 px = detection, 8 px = recognition (human vs non-human)
OUT["thermal_limit"] = {
    "recognition_8px_altitude_m": round(alt_for_px(8, 0.5, 640, 32), 1),
    "detection_2px_altitude_m": round(alt_for_px(2, 0.5, 640, 32), 1),
    "note": "a head-only exposure shrinks the critical dimension to ~0.25 m, halving both limits",
}

# ============================================================ 2. THERMAL CONTRAST DECAY
# Lumped-capacitance cooling of the exposed skin/garment envelope.
# tau derived from body-in-water vs body-in-air convective boundary conditions.
def decay(T0, Tamb, tau, minutes=240):
    t = np.arange(0, minutes + 1, 2)
    return t, (T0 - Tamb) * np.exp(-t / tau)

t_axis, dT_immersed = decay(34.0, 26.0, 34.0)    # immersed / soaked: fast
_, dT_dry = decay(34.0, 26.0, 130.0)             # dry on a roof, clothed: slow

NETD, CLUTTER, TAU_ATM = 0.05, 0.30, 0.55        # K, K, transmittance @150 m coastal haze
def snr(dT, fill):
    return (dT * TAU_ATM * fill) / math.sqrt(NETD**2 + CLUTTER**2)

# exposed person on open water: fill 0.55 ; head-only in debris: fill 0.06
snr_immersed = [round(float(snr(d, 0.55)), 2) for d in dT_immersed]
snr_headonly = [round(float(snr(d, 0.06)), 2) for d in dT_immersed]

def first_below(series, thr, t):
    for ti, s in zip(t, series):
        if s < thr:
            return int(ti)
    return None

OUT["thermal"] = {
    "netd_K": NETD, "clutter_sigma_K": CLUTTER, "atm_transmittance": TAU_ATM,
    "detect_threshold_snr": 4.0,
    "t_min": t_axis.tolist()[::5],
    "dT_immersed_K": [round(float(x), 2) for x in dT_immersed[::5]],
    "dT_dry_K": [round(float(x), 2) for x in dT_dry[::5]],
    "snr_exposed": snr_immersed[::5],
    "snr_head_only": snr_headonly[::5],
    "minutes_exposed_to_blind": first_below(snr_immersed, 4.0, t_axis),
    "minutes_headonly_to_blind": first_below(snr_headonly, 4.0, t_axis),
}

# ============================================================ 3. RF / DIELECTRIC
# Attenuation of a phone radio through saturated debris and through water.
# Literature ranges (dB per metre of material):
ATTEN = {  # band : (wet concrete/rubble dB/m, freshwater dB/m at typical conductivity)
    "BLE/WiFi 2.4 GHz": (150, 300),
    "LoRa 865-867 MHz": (55, 120),
    "UWB 0.5-2.25 GHz (low band)": (80, 200),
    "UWB 3-5 GHz": (140, 400),
}
BUDGET = {"BLE/WiFi 2.4 GHz": 95, "LoRa 865-867 MHz": 151,
          "UWB 0.5-2.25 GHz (low band)": 60, "UWB 3-5 GHz": 60}

rf = {}
for band, (a_deb, a_wat) in ATTEN.items():
    rf[band] = {
        "link_budget_dB": BUDGET[band],
        "max_depth_wet_rubble_m": round(BUDGET[band] / a_deb, 2),
        "max_depth_freshwater_m": round(BUDGET[band] / a_wat, 2),
    }
OUT["rf"] = rf

# skin depth (EM penetration into water) — the formal reason a submerged phone is silent
def skin_depth(f_hz, sigma_s_m=0.01, mu_r=1.0):
    mu = 4 * math.pi * 1e-7 * mu_r
    return 1.0 / math.sqrt(math.pi * f_hz * mu * sigma_s_m)
OUT["skin_depth_m"] = {f"{int(f/1e6)}MHz": round(skin_depth(f), 3)
                       for f in (433e6, 866e6, 2400e6, 5000e6)}

# ============================================================ 4. SEARCH-SPACE COMPRESSION
def void_accounting(floor_area_m2=100, storeys=2, storey_h=2.8, bulking=1.35,
                    void_fraction=0.08, cell_volume_m3=2.5):
    gross = floor_area_m2 * storeys * storey_h
    debris = gross * bulking
    void = debris * void_fraction
    return dict(gross_volume_m3=round(gross, 1), debris_volume_m3=round(debris, 1),
                survivable_void_m3=round(void, 1),
                search_cells_2p5m3=round(void / cell_volume_m3, 1),
                debris_per_void=round(debris / void, 1))

OUT["void"] = {k: void_accounting(void_fraction=v) for k, v in
               {"conservative": 0.05, "central": 0.08, "optimistic": 0.12}.items()}
# naive search volume equivalents for the same 60 m^3 of void
OUT["equivalence"] = {
    "open_field_sector_1km2_100m_deep": 1e6 * 100,
    "radio_derived_ball_at_10m_range": (4 / 3) * math.pi * 10**3,
    "logs_of_compression": {
        "field_1km2": round(math.log10((1e6 * 100) / 60.5), 1),
        "rubble_heap_20m_radius": round(math.log10(((4 / 3) * math.pi * 20**3) / 60.5), 1),
    },
}

# ============================================================ 5. PRECISION ALGEBRA
def ppv(prior, tpr, fpr):
    num = prior * tpr
    return num / (num + (1 - prior) * fpr)

priors = [1e-4, 1e-3, 1e-2, 0.05, 0.10, 0.25, 0.50]
OUT["ppv"] = {
    "priors": priors,
    "single_modality_tpr0.90_fpr0.20": [round(ppv(p, .90, .20), 4) for p in priors],
    "two_modality_tpr0.81_fpr0.04": [round(ppv(p, .81, .04), 4) for p in priors],
    "three_modality_tpr0.729_fpr0.008": [round(ppv(p, .729, .008), 4) for p in priors],
}
# how good must ONE modality be to hit 0.99 PPV at a given prior?
def fpr_needed(prior, tpr, target_ppv=0.99):
    # target = prior*tpr / (prior*tpr + (1-prior)*fpr)
    return round((prior * tpr / target_ppv - prior * tpr) / (1 - prior), 5)
OUT["fpr_needed_for_99ppv"] = {f"prior_{p}": fpr_needed(p, 0.90) for p in (0.10, 0.01, 0.001)}

# ============================================================ 6. SPRT
def sprt(alpha, beta, llr_h1, llr_h0):
    A = math.log((1 - beta) / alpha)
    B = math.log(beta / (1 - alpha))
    return dict(A=round(A, 2), B=round(B, 2),
                E_samples_H1=round(abs(((1 - beta) * A + beta * B) / llr_h1), 1),
                E_samples_H0=round(abs(((1 - alpha) * B + alpha * A) / llr_h0), 1))
OUT["sprt"] = {f"alpha_{a}": sprt(a, 0.05, 1.6, -0.9) for a in (1e-2, 1e-3, 1e-4)}

# ============================================================ 7. COVERAGE CERTIFICATE
OUT["coverage"] = {f"p_neg_given_occupied_{m}": {f"k={k}": round(1 - m**k, 5)
                                                 for k in (1, 3, 5, 8, 12, 20, 30)}
                   for m in (0.5, 0.3, 0.15, 0.05)}

# ============================================================ 8. SUBMODULAR ALLOCATION
rng = np.random.default_rng(7)
def greedy(P, budget):
    n_cells, n_sensors = P.shape
    chosen, cov = [], np.zeros(n_cells)
    for _ in range(budget):
        gains = [float(np.sum(1 - (1 - cov) * (1 - P[:, s]))) for s in range(n_sensors) if s not in chosen]
        best = max(range(len(gains)), key=lambda i: gains[i])
        idx = [s for s in range(n_sensors) if s not in chosen][best]
        chosen.append(idx); cov = 1 - (1 - cov) * (1 - P[:, idx])
    return chosen, float(np.sum(cov))

def brute(P, budget):
    from itertools import combinations
    best, arg = -1, None
    for c in combinations(range(P.shape[1]), budget):
        v = float(np.sum(1 - np.prod(1 - P[:, list(c)], axis=1)))
        if v > best: best, arg = v, c
    return arg, best

ratios = []
for _ in range(300):
    P = rng.random((40, 9)) ** 3
    ratios.append(greedy(P, 3)[1] / brute(P, 3)[1])
OUT["submodular"] = {"trials": 300, "min_ratio": round(min(ratios), 4),
                     "mean_ratio": round(float(np.mean(ratios)), 4),
                     "theory_guarantee": round(1 - 1 / math.e, 4)}

# ============================================================ 9. COST OF FALSE ALARM
def cost(ppv_, tpr=0.90, alerts=50, breach_min=12):
    tp = alerts * ppv_; fp = alerts - tp
    return dict(true_alerts=round(tp, 1), false_alerts=round(fp, 1),
                team_minutes_wasted=round(fp * breach_min),
                team_minutes_per_true_alert=round((alerts * breach_min) / max(tp, 1e-9), 1))
OUT["cost"] = {f"ppv_{p}": cost(p) for p in (0.20, 0.33, 0.60, 0.83, 0.99)}

# ============================================================ 10. DRONE SWATH THROUGHPUT
def sweep(alt_m, hfov_deg, v_ms, overlap=0.3, battery_min=25, turnaround_min=6):
    swath = 2 * alt_m * math.tan(math.radians(hfov_deg) / 2)
    eff = swath * (1 - overlap)
    usable = battery_min - turnaround_min
    area = eff * v_ms * usable * 60
    return dict(swath_m=round(swath, 1), effective_swath_m=round(eff, 1),
                area_per_sortie_m2=round(area),
                area_per_sortie_ha=round(area / 1e4, 2))
OUT["drone_sweep"] = {f"{a}m": sweep(a, 32, 8) for a in (30, 60, 120)}

json.dump(OUT, open("abhedya/research/data/analysis.json", "w"), indent=1)

# ---- console summary of the numbers we will actually quote
print("thermal recognition limit (m):", OUT["thermal_limit"]["recognition_8px_altitude_m"])
print("thermal SNR exposed every 30 min:",
      OUT["thermal"]["snr_exposed"][:9])
print("minutes to thermal blindness (exposed / head-only):",
      OUT["thermal"]["minutes_exposed_to_blind"], "/", OUT["thermal"]["minutes_headonly_to_blind"])
print("\nRF max depth wet rubble (m):", {k: v["max_depth_wet_rubble_m"] for k, v in rf.items()})
print("skin depth (m):", OUT["skin_depth_m"])
print("\nvoid cells:", {k: v["search_cells_2p5m3"] for k, v in OUT["void"].items()})
print("compression log10:", OUT["equivalence"]["logs_of_compression"])
print("\nPPV:", json.dumps(OUT["ppv"], indent=1))
print("FPR needed for 99% PPV:", OUT["fpr_needed_for_99ppv"])
print("\nSPRT:", OUT["sprt"])
print("submodular:", OUT["submodular"])
print("cost:", OUT["cost"])
print("drone sweep:", OUT["drone_sweep"])
