"""Light landslide graphic: one timeline, two systems, clear scope split."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Polygon

BG="#0A1018"; INK="#E8EEF5"; MUTE="#7C8FA6"
AMBER="#FFB020"; CYAN="#3BC9F5"; RED="#FF5D5D"; GREEN="#4ADE80"
plt.rcParams.update({"figure.facecolor":BG,"axes.facecolor":BG,"savefig.facecolor":BG,
 "text.color":INK,"font.family":"DejaVu Sans","figure.dpi":160,
 "savefig.bbox":"tight","savefig.pad_inches":0.22})

import os
fig, ax = plt.subplots(figsize=(13.0, 2.9) if os.environ.get("COMPACT")=="1" else (13.0, 4.6))
ax.set_xlim(0, 100); ax.set_ylim(26, 104); ax.axis("off")

import os
BARE = os.environ.get("BARE") == "1"
import os as _os
_compact = _os.environ.get("COMPACT") == "1"
if not BARE and not _compact:
    ax.text(0, 103, "One hazard, two clocks — and we only claim the half we can prove",
            fontsize=13.5, fontweight="bold", va="top")
    ax.text(0, 95.5, "SIREN is a deliberately light extension: it covers the warning gap we could not ignore, not the core of this project",
            fontsize=8.6, color=MUTE, va="top")
elif os.environ.get("COMPACT") == "1":
    ax.set_ylim(26, 94)
    for t in ax.texts:
        pass
else:
    ax.set_ylim(26, 94)

yb = 60                                     # spine
# ── phase bands
for x0, x1, col, lab, sub in [
        (2, 25, "#1B2A38", "days → hours", "monsoon rain · 10-day antecedent"),
        (25, 46, "#2A2118", "hours → minutes", "slope saturating · pore pressure rising")]:
    ax.add_patch(FancyBboxPatch((x0, yb - 4.5), x1 - x0, 9,
                                boxstyle="round,pad=0.15,rounding_size=1.0",
                                fc=col, ec="#243342", lw=0.8))
    ax.text((x0 + x1) / 2, yb + 1.9, lab, fontsize=7.8, color=MUTE, ha="center")
    ax.text((x0 + x1) / 2, yb - 2.2, sub, fontsize=6.9, color="#5A6B7E", ha="center")

ax.add_patch(FancyBboxPatch((46.5, yb - 4.5), 51.5, 9,
                            boxstyle="round,pad=0.15,rounding_size=1.0",
                            fc="#17251F", ec="#243342", lw=0.8))
ax.text(72, yb + 1.9, "minutes → days", fontsize=7.8, color=MUTE, ha="center")
ax.text(72, yb - 2.2, "debris field · void spaces · survivors still alive",
        fontsize=6.9, color="#5A6B7E", ha="center")

# ── failure marker
ax.add_patch(FancyArrowPatch((46, yb - 6.4), (46, yb + 6.6), arrowstyle="-|>",
                             mutation_scale=17, color=RED, lw=2.2))
ax.text(46, yb - 9.6, "FAILURE  ≈ 02:00", fontsize=8.6, color=RED,
        fontweight="bold", ha="center")

# ── SIREN span (secondary)
ax.add_patch(FancyArrowPatch((2.5, yb + 20), (45.3, yb + 20), arrowstyle="-|>",
                             mutation_scale=15, color=CYAN, lw=2.2))
ax.text(2.5, yb + 23.5, "SIREN  ·  warn the sleeping", fontsize=10.5, color=CYAN, fontweight="bold")
ax.text(2.5, yb + 15.6, "saturated catchment (hours)  ×  ground motion (17–138 s)",
        fontsize=7.7, color=MUTE)
ax.text(2.5, yb + 12.4, "≈ ₹25,000 per hamlet  ·  3 nodes + 1 siren", fontsize=7.3, color=CYAN)

# ── PRISM span (primary)
ax.add_patch(FancyArrowPatch((47.5, yb + 20), (97, yb + 20), arrowstyle="-|>",
                             mutation_scale=16, color=AMBER, lw=3.0))
ax.text(47.5, yb + 23.5, "PRISM  ·  find the living", fontsize=10.5, color=AMBER, fontweight="bold")
ax.text(47.5, yb + 15.6,
        "void prior from open data → pods inside the debris → evidence algebra → certified clearance",
        fontsize=7.7, color=MUTE)
ax.text(47.5, yb + 12.4, "built · measured · demoed", fontsize=7.3, color=AMBER, fontweight="bold")

# ── weight bars
ax.add_patch(FancyBboxPatch((47.5, 36), 49.5, 6.0, boxstyle="round,pad=0.25,rounding_size=1.1",
                            fc=AMBER, alpha=.20, ec=AMBER, lw=1.1))
ax.text(72.2, 39, "PRIMARY SOLUTION", fontsize=9.4, color=AMBER, ha="center",
        va="center", fontweight="bold")

ax.add_patch(FancyBboxPatch((2.5, 36), 42.5, 6.0, boxstyle="round,pad=0.25,rounding_size=1.1",
                            fc=CYAN, alpha=.08, ec=CYAN, lw=1.0, ls="--"))
ax.text(23.7, 39, "SECONDARY · designed, partially validated", fontsize=8.6, color=CYAN,
        ha="center", va="center")

ax.text(0, 30.5,
        "We do not claim landslide prediction. SIREN detects a slope that has already begun to move — "
        "a real but narrow 17–138 s window, on one instrumented path.",
        fontsize=7.8, color=MUTE, style="italic")
suffix = "_compact" if os.environ.get("COMPACT")=="1" else ("_bare" if BARE else "")
fig.savefig("abhedya/research/figures/f10_scope%s.png" % suffix)
print("ok f10_scope")
