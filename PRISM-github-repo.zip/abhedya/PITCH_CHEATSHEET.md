# PRISM — pitch crib sheet
### One page to hold in your hand behind the laptop. INNOVEX 2026 · PS-5 Abhedya · Focus Area 03

---

## The 30-second version (memorise this, not the slides)

> "Every SAR tool in the field answers *can I see a body?* — thermal, radar, listening devices, mesh SOS apps. In a real Indian debris field the chance that any given 2.5 m³ of rubble holds a live survivor is about one in a thousand. At that prior, a 95 %-accurate detector is wrong four times out of five. So we did not build a better detector. **PRISM shrinks the search from a hundred million cubic metres to about 24 cells, puts a ₹6,000 pod inside the void instead of looking through it, and refuses to send a team until the evidence crosses a stated false-alarm threshold.** And when it declares a sector empty, it hands you a certificate — because that is the decision that saves the next village."

**If you only get one sentence:** *"We don't detect better — we make the search small enough that detection is even a fair question, and then we make the answer auditable."*

---

## The four numbers to say out loud

| Number | What it means | Where it comes from |
|---|---|---|
| **10⁻⁴ to 10⁻²** | prior probability a given cell holds a live survivor | 14 rescued from a debris field of thousands of structures (Wayanad 2024) |
| **6.2 orders of magnitude** | search-space compression, 10⁸ m³ → 24 cells | void accounting, `analysis.json → void` |
| **41 h → 1.1 h** | time to clear one 200 × 200 m sector | swath × coverage model, `analysis.json → drone_sweep` |
| **0.99 / 10⁻³** | alert precision target / false-alarm budget per cell | PPV algebra + SPRT, §4 |

---

## Stage plan (3 people, 5 minutes)

| Who | Owns | Opening line |
|---|---|---|
| **P1** | Slides 1–3 (stakes, the lie) + live Overpass/SACHET call | "This is the maths that killed the last generation of SAR dashboards." |
| **P2** | Slide 7 + the pod demo, including the **decoy test** | "Now I am going to try to make my own system lie to you." |
| **P3** | Slides 9, 11, 13 (SPRT, certificate, offline rollback) | "Here is the only demo in this room that shows you a *negative* result." |

Hand-off discipline: P1 never touches hardware, P2 never touches the console, P3 owns the kill-the-network moment. Rehearse the hand-offs twice; judges read hesitation as unfinished work.

---

## Hard questions, short answers

**"So you're solving landslides too?"**
No — PRISM is search and rescue. Landslides are the hazard that *creates* the debris field. We have one slide on the warning half (SIREN): a small, honest attempt that costs ₹25,350 per hamlet and detects a slope that has *already started moving* 17–138 s before the front arrives. We do **not** claim to predict which slope fails days ahead — that needs geotechnical instrumentation at 10–50× the cost. Saying that out loud is the point.

**"Isn't this just NASA's FINDER?"**
FINDER is superb at what it does — breathing through 30 ft of rubble, proven in Nepal and Mexico City. But it is a **handheld point interrogator**: one operator, one spot, one device, and its own programme notes that a precise locator function was left as future work. PRISM is a **distributed, self-reporting network with a void prior and an evidence algebra** — it answers "which 24 cells in this valley do I search first, and when can I stop?" No handheld answers that question, at any price.

**"Isn't this just Meshtastic / a BLE mesh?"**
Meshtastic is transport — a very good one, which is why we use LoRa at IN865. The delta is (a) our packets carry **log-likelihood ratios**, not coordinates, so the network does part of the inference; (b) the **mesh topology itself is a sensing channel**; (c) a plain SOS mesh floods a commander with low-precision alerts, which §4 shows is actively worse than silence. We treat the mesh as a sensor, not a pipe.

**"100 % reliability — prove it."**
We will not claim 100 %. In an open world nobody can, and a team that claims it hasn't read its own confusion matrix. What we claim is *bounded*: false-alarm probability ≤ 10⁻³ per cell (α is a visible SPRT threshold), monotone precision as passes accumulate, an auditable coverage certificate for cleared sectors, and **graceful degradation** — when the effective number of independent channels drops to one, the system refuses to auto-dispatch. That is a stronger engineering position than a fake 100 %, and it is the one a district magistrate can sign off on.

**"Your 60 GHz module isn't low-band UWB."**
Correct, and we say so on the slide. A 0.5–2.25 GHz UWB radar is not a 24-hour part; the MR60BHA1-class module is an honest stand-in that proves the *architecture* — evidence packet, fusion, SPRT, certificate, allocation. The architecture does not depend on that specific radio; swapping in a low-band UWB front end changes one driver, not the design.

**"What's actually new? Bayesian search theory is from the 1970s."**
Bayesian search theory is exactly right, and it has been used for lost-at-sea and MH370-style problems at *strategic* timescales by specialists. What has never been fielded is (a) the **prior built automatically from open data per building**, (b) **sensors placed inside the void network** rather than outside it, (c) **cross-modality likelihood accumulation in real time offline**, and (d) **a certificate that lets you release a sector**. The novelty is the integration and the deployment economics, and we state it that way instead of pretending the mathematics is ours.

**"Where does the prior p₀ come from? Isn't that made up?"**
It comes from three verifiable things: building stock and geometry from OSM (2,495 building ways pulled live for a 2 km² Mangaluru box — you can watch me run it), hazard severity from the NDMA SACHET CAP stream (98 active items right now) and IMD district warnings, and elapsed time from the CAP `onset` timestamp. The **void fraction (5–12 %) is a config parameter we expose**, not a hidden constant — a structural engineer can override it in thirty seconds. We would rather show you the knob than defend a magic number.

**"What if the network is down?"**
That is the design assumption, not the edge case. Every feed is cached with ETag and last-good timestamp; tiles and geometry are pre-fetched at mission start; the entire server is one FastAPI process, one SQLite file and one laptop. The mesh is the transport for new evidence. I will kill the network on stage and the console will keep reasoning — then resync when it comes back.

**"Who uses this, and who pays?"**
First 24 hours: the **local** community and the village-level responder, because pods are drop-and-forget and cost ₹6–9k — not a national team that arrives on day 4, which is exactly what happened in Wayanad. Then SDRF/NDRF as a force multiplier over their existing dogs, FINDER-class devices and structural specialists: PRISM tells them where to go first. A district can fund dozens of pods; it cannot fund dozens of rescue radars.

**"Privacy / DPDP Act?"**
No biometrics, no facial recognition, no cloud. Position and vitals evidence stay inside the incident's own console, retained ≤30 days post-incident, processed under disaster-response necessity. The sensing is *presence and breathing*, not identity.

**"Spectrum / drone legality?"**
Pods at 865–867 MHz, ≤1 W ERP, duty-cycle scheduled — licence-exempt in India, and we do not claim otherwise. No 2.4 GHz high-power mesh. Any UAV use is optional in the architecture and follows DGCA zone rules.

**"Why won't this fail in the rain, which is when landslides happen?"**
Because the rain is *in* the model. IMD nowcast intensity maps to debris water content, which sets an attenuation penalty α that **reduces the penetration depth we claim and increases the number of passes required**. When IMD says >15 mm/h, PRISM visibly becomes more conservative on stage. A system whose confidence responds to the weather feed is a system that will not lie to a commander in a monsoon.

**"What is the single biggest risk to this build in 24 hours?"**
Integration, not invention. Which is why the schema is frozen in hour 0–2, each of us owns a demo-visible artefact by hour 12, and four hours of buffer are on the Gantt as a *task*, not a hope. If we lose the hardware track entirely, the demo still runs on replayed evidence packets — the fusion, certificate and allocation are all software.

---

## Traps to avoid on stage

1. **Do not say "AI".** There is no model to hide behind; the argument is arithmetic and it is stronger for it. Say "likelihood ratios" and "thresholds".
2. **Do not show a map of dots.** Dots are what everyone shows. Show posteriors, and show the grey-out when a sector is certified.
3. **Do not skip the decoy test** because you are short of time. The warm-water-bottle result is the most persuasive ten seconds in the pitch.
4. **Do not over-claim penetration depth.** Say the number the physics supports (0.3–0.5 m in the demo box), then say what is modelled.
5. **If a judge finds an error, agree and bound it.** "You're right — that assumption is exactly why we expose the parameter and report effective k" beats defending a number you cannot derive.

---

## Files

| File | What it is |
|---|---|
| `PRISM_SAR_dossier.md` | The engineering document — gap analysis, three innovations, the precision mathematics, data pipeline, build plan, sources |
| `PRISM_pitch.pptx` | 16-slide deck, figures generated from the analysis |
| `research/analysis.py` → `data/analysis.json` | Every number in the deck and dossier, reproducible |
| `research/figures.py` → `figures/f1…f9.png` | Deck art, generated from the JSON |
| `research/data/sachet_*.xml` | Real CAP payloads pulled live on 11 Nov 2026 |
| `check_deck.py` | Layout/overflow checker (0 flags = nothing overflows) |
