"""Build PRISM_pitch.pptx — 16 slides, 16:9, dark, figure-driven."""
import json, os
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

A = json.load(open("abhedya/research/data/analysis.json"))
FIG = "abhedya/research/figures"
P = Presentation()
P.slide_width, P.slide_height = Inches(13.333), Inches(7.5)

BG   = RGBColor(0x0A, 0x10, 0x18)
INK  = RGBColor(0xE8, 0xEE, 0xF5)
MUTE = RGBColor(0x7C, 0x8F, 0xA6)
DIM  = RGBColor(0x4A, 0x5B, 0x6E)
AMBER= RGBColor(0xFF, 0xB0, 0x20)
CYAN = RGBColor(0x3B, 0xC9, 0xF5)
RED  = RGBColor(0xFF, 0x5D, 0x5D)
GREEN= RGBColor(0x4A, 0xDE, 0x80)
VIOL = RGBColor(0xA7, 0x8B, 0xFA)
WHITE= RGBColor(0xFF, 0xFF, 0xFF)

def blank():
    s = P.slides.add_slide(P.slide_layouts[6])
    r = s.shapes.add_shape(1, 0, 0, P.slide_width, P.slide_height)
    r.fill.solid(); r.fill.fore_color.rgb = BG; r.line.fill.background()
    r.shadow.inherit = False
    return s

def tb(s, x, y, w, h, text, size=14, color=INK, bold=False, align=PP_ALIGN.LEFT,
       spacing=1.25, anchor=MSO_ANCHOR.TOP, italic=False, font="Calibri"):
    box = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame; tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = anchor
    lines = text.split("\n")
    for i, ln in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.line_spacing = spacing
        run = p.add_run(); run.text = ln
        f = run.font; f.size = Pt(size); f.bold = bold; f.italic = italic
        f.color.rgb = color; f.name = font
    return box

def head(s, kicker, title, sub=None, kcol=AMBER):
    bar = s.shapes.add_shape(1, Inches(0.58), Inches(0.40), Inches(0.05), Inches(1.30))
    bar.fill.solid(); bar.fill.fore_color.rgb = kcol; bar.line.fill.background()
    bar.shadow.inherit = False
    tb(s, 0.78, 0.36, 12.0, 0.28, kicker.upper(), 10.5, kcol, bold=True)
    tb(s, 0.76, 0.66, 11.95, 0.92, title, 25, INK, bold=True, spacing=1.05)
    if sub:
        tb(s, 0.78, 1.53, 11.9, 0.42, sub, 12.5, MUTE, spacing=1.2)

def rule(s, y=None):
    return

def pic(s, path, x, y, w):
    s.shapes.add_picture(os.path.join(path), Inches(x), Inches(y), width=Inches(w))

def chip(s, x, y, w, h, label, color):
    r = s.shapes.add_shape(5, Inches(x), Inches(y), Inches(w), Inches(h))
    r.fill.solid(); r.fill.fore_color.rgb = color; r.line.fill.background()
    r.shadow.inherit = False
    tf = r.text_frame; tf.word_wrap = True
    tf.margin_left = tf.margin_right = Inches(0.06)
    p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
    run = p.add_run(); run.text = label
    run.font.size = Pt(10.5); run.font.bold = True; run.font.color.rgb = BG
    run.font.name = "Calibri"

def stat(s, x, y, big, label, col, w=2.9):
    tb(s, x, y, w, 0.85, big, 40, col, bold=True, spacing=0.95)
    tb(s, x, y + 0.78, w, 0.7, label, 11, MUTE, spacing=1.25)

# ═══════════════════════════════════════════════════ 1 · TITLE
s = blank()
bar = s.shapes.add_shape(1, 0, 0, Inches(0.14), P.slide_height)
bar.fill.solid(); bar.fill.fore_color.rgb = AMBER; bar.line.fill.background(); bar.shadow.inherit = False
tb(s, 0.9, 1.5, 6.0, 0.35, "INNOVEX 2026  ·  SEASON 02  ·  NSS IT WING", 10.5, MUTE, bold=True)
tb(s, 0.85, 1.9, 9.0, 1.35, "PRISM", 82, INK, bold=True, spacing=0.9)
tb(s, 0.9, 3.15, 11.0, 0.9, "Probabilistic Rescue-space Inference & Survivor Mapping", 24, AMBER, bold=True)
tb(s, 0.9, 4.05, 10.6, 1.5,
   "Search & Rescue is not a detection problem. It is a search-space and evidence problem.\n"
   "PRISM shrinks the space by 10⁶, drops sensors inside the debris, and refuses to send a team\n"
   "until the posterior is decisive.", 14, INK, spacing=1.45)
chip(s, 0.9, 5.75, 2.5, 0.34, "PS 5 · PROJECT ABHEDYA", AMBER)
chip(s, 3.55, 5.75, 2.9, 0.34, "FOCUS AREA 03 · SEARCH & RESCUE", CYAN)
chip(s, 6.6, 5.75, 2.2, 0.34, "24-HOUR BUILD", VIOL)
tb(s, 0.9, 6.55, 11.0, 0.4,
   "Nitte University, Deralakatte, Mangaluru  ·  3-member team  ·  every number in this deck is computed, not asserted",
   10, DIM, italic=True)

# ═══════════════════════════════════════════════════ 2 · THE CLIFF
s = blank()
head(s, "the stakes", "Survival is a clock, and the clock starts before rescuers arrive",
     "Published entrapment cohorts · Wayanad 2024: drone-based life detection reached the debris field on day 4")
rule(s)
stat(s, 0.65, 2.05, "≈90 %", "alive if extricated\nwithin 24 hours", GREEN)
stat(s, 3.55, 2.05, "≈57 %", "alive at 48 hours", AMBER)
stat(s, 6.45, 2.05, "≈21 %", "alive at 72 hours", RED)
stat(s, 9.35, 2.05, "AUC 0.895", "extrication time as a\nmortality predictor\ncritical cut-off ≈ 21 h", CYAN, w=3.4)
box = s.shapes.add_shape(5, Inches(0.62), Inches(3.85), Inches(12.05), Inches(1.05))
box.fill.solid(); box.fill.fore_color.rgb = RGBColor(0x16, 0x22, 0x2E)
box.line.color.rgb = AMBER; box.line.width = Pt(1); box.shadow.inherit = False
tf = box.text_frame; tf.word_wrap = True
tf.margin_left = Inches(0.25); tf.margin_top = Inches(0.14)
p = tf.paragraphs[0]
r = p.add_run(); r.text = "The scarce resource is not technology — it is team-hours, dogs and machine-hours. "
r.font.size = Pt(15); r.font.bold = True; r.font.color.rgb = AMBER; r.font.name = "Calibri"
r2 = p.add_run(); r2.text = "Every false alarm spends them. So the design goal is not 'detect better', it is 'spend fewer team-minutes per survivor found'."
r2.font.size = Pt(15); r2.font.color.rgb = INK; r2.font.name = "Calibri"
tb(s, 0.62, 5.15, 6.0, 0.3, "what the record shows in India", 12, CYAN, bold=True)
tb(s, 0.62, 5.5, 12.0, 1.6,
   "· Wayanad, 30 July 2024 — no connectivity from hour zero; roads and the Chooralmala bridge gone; a 190-ft Bailey bridge had to be built\n"
   "· Heavy rain and sludge obstructed NDRF movement; heavy machinery was in shortage; Army canine squads had to be airlifted in\n"
   "· 14 rescued · 352 evacuated · 111 deceased retrieved · remains recovered from the Chaliyar river, kilometres downstream\n"
   "· The debris field was thousands of structures. The prior probability that any given 2.5 m³ volume holds a live survivor is 10⁻⁴ to 10⁻²",
   11.5, INK, spacing=1.5)

# ═══════════════════════════════════════════════════ 3 · THE LIE
s = blank()
head(s, "the uncomfortable maths", "A “95 %-accurate” detector is wrong four times out of five here",
     "Positive predictive value at the priors that actually obtain in a debris field · TPR 0.90")
rule(s)
pic(s, f"{FIG}/f3_precision.png", 0.5, 2.28, 8.15)
tb(s, 9.15, 2.30, 3.6, 0.3, "READ THE FIRST ROW", 10.5, RED, bold=True)
tb(s, 9.15, 2.68, 3.65, 2.5,
   "prior 10⁻³, one sensor:\nPPV = 0.0045\n\n→ 995 out of every 1,000 alerts\n    are wrong.\n\n"
   "This is why field teams\ndistrust drone alerts.", 13, INK, spacing=1.35)
box = s.shapes.add_shape(5, Inches(9.15), Inches(5.32), Inches(3.6), Inches(1.62))
box.fill.solid(); box.fill.fore_color.rgb = RGBColor(0x16, 0x22, 0x2E)
box.line.color.rgb = CYAN; box.line.width = Pt(1); box.shadow.inherit = False
tf = box.text_frame; tf.word_wrap = True; tf.margin_left = Inches(0.2); tf.margin_top = Inches(0.12)
p = tf.paragraphs[0]
r = p.add_run(); r.text = "To hit 0.99 PPV with ONE modality at prior 0.01 you would need a false-positive rate of 9 × 10⁻⁵.\n\nNo fieldable SAR sensor has that specificity."
r.font.size = Pt(11); r.font.color.rgb = INK; r.font.name = "Calibri"

# ═══════════════════════════════════════════════════ 4 · FAILURE REGISTER
s = blank()
head(s, "gap analysis", "Where deployed SAR technology physically breaks", "Each row is a measured failure mechanism, not an opinion")
rule(s)
rows = [
    ("Optical / thermal UAV\nat 100–400 ft", "IR reads surface temperature and cannot pass solids. Recognition dies above ~70 m for a 0.5 m target, ~35 m for a head-only exposure.", "Canopy, roofs, culverts, vehicles ⇒ nothing visible. Says 'cleared' when nothing was seen.", RED),
    ("Thermal after wetting", "Wet, immersed or buried bodies converge on ambient temperature in tens of minutes. ΔT often < 1 K on arrival.", "SNR drops below the detectability floor 20–30 min after wetting (exposed) — already below it for head-only.", RED),
    ("UWB / GPR through rubble", "Attenuation scales with moisture. 0.5–2.25 GHz survives ~0.75 m of saturated rubble; 3–5 GHz only ~0.43 m.", "Typical burial is 1.5–3 m. Range claims collapse precisely in the rain that caused the disaster.", AMBER),
    ("Acoustic listening devices", "Need site-wide silence; sound is blocked within a few feet of rubble; need a conscious survivor who chooses to respond.", "Impossible during rain, machinery, generators and multi-team ops. Serialises the whole site.", AMBER),
    ("BLE / Wi-Fi mesh SOS apps", "95 dB link budget ⇒ ~0.6 m through saturated rubble, ~0.3 m through fresh water. Skin depth at 2.4 GHz ≈ 0.10 m.", "Finds phones of people who are NOT trapped. Creates the alert flood that trains commanders to ignore it.", VIOL),
    ("Dashboards / CAD clones", "Digitise a voice-report workflow; no uncertainty model, no notion of 'cleared', die when the network dies.", "Beautiful demo, zero change to any decision.", VIOL),
]
y = 1.92
for name, mech, cost, col in rows:
    r = s.shapes.add_shape(1, Inches(0.62), Inches(y), Inches(0.055), Inches(0.78))
    r.fill.solid(); r.fill.fore_color.rgb = col; r.line.fill.background(); r.shadow.inherit = False
    tb(s, 0.82, y - 0.02, 2.5, 0.8, name, 11, col, bold=True, spacing=1.15)
    tb(s, 3.45, y - 0.02, 4.5, 0.85, mech, 10, INK, spacing=1.25)
    tb(s, 8.15, y - 0.02, 4.6, 0.85, cost, 10, MUTE, spacing=1.25)
    y += 0.87
tb(s, 0.82, 7.04, 12.0, 0.3, "→ five gaps (G1–G5): no prior · sensors are outside-in · no deliberation · no negative evidence · no offline-native reasoning",
   10.5, AMBER, bold=True)

# ═══════════════════════════════════════════════════ 5 · PHYSICS
s = blank()
head(s, "the two walls", "Thermal is blind by hour two. Radio cannot reach them at all.",
     "Both computed from sensor physics — see research/analysis.py")
rule(s)
pic(s, f"{FIG}/f1_failure_physics.png", 0.55, 2.02, 11.75)
tb(s, 0.62, 6.95, 12.0, 0.45,
   "Left: a person exposed on water becomes thermally undetectable 20–30 min after wetting; a head-only exposure in debris is already below the floor on arrival. "
   "Right: no 2.4 GHz device reaches a body at 1.5–3 m. The fix is not a better sensor — it is putting the sensor inside the void.",
   10, MUTE, spacing=1.3)

# ═══════════════════════════════════════════════════ 6 · GAPS → INSIGHT
s = blank()
head(s, "the reframe", "Stop asking “can I see a body?” — ask “which 24 cells first?”")
rule(s)
pic(s, f"{FIG}/f2_search_compression.png", 0.5, 2.66, 8.2)
tb(s, 8.9, 2.30, 3.85, 0.3, "THE ONE INSIGHT", 10.5, GREEN, bold=True)
tb(s, 8.9, 2.68, 3.9, 4.4,
   "A collapse is a structure with a\npredictable void topology — FEMA\nUSAR taxonomy: pancake, lean-to,\nV-shape, A-frame, cantilever.\n\n"
   "2-storey, 100 m² dwelling =\n756 m³ of debris holding\n38–91 m³ of survivable void.\n\n"
   "That is 15–36 cells of 2.5 m³ —\nnot 10⁸ m³ of valley.\n\n"
   "Every institution in this field\noptimises throughput over the\nwhole area. Nobody shrinks the\narea first.", 11.5, INK, spacing=1.4)

# ═══════════════════════════════════════════════════ 7 · INNOVATION 1
s = blank()
head(s, "innovation 01", "Put the sensor inside the void network", "PRISM-Cell — a 220 g drop-and-forget pod, ₹6–9k, 7-day life", AMBER)
rule(s)
pic(s, f"{FIG}/f5_cell_anatomy.png", 0.5, 2.35, 8.15)
tb(s, 8.85, 2.02, 3.9, 0.3, "WHY IT WORKS", 10.5, AMBER, bold=True)
tb(s, 8.85, 2.38, 3.95, 4.6,
   "Range requirement drops from tens of\nmetres to 0.4–1.5 m, because the pod is\nalready in the void. "
   "Every attenuation\nwall in the gap analysis is routed around\ninstead of argued with.\n\n"
   "· 60 GHz FMCW presence + breathing\n· 3-axis geophone → TDOA from 3 pods\n· 865 MHz LoRa IN865 backhaul (legal,\n   ≤1 W ERP, duty-cycle compliant)\n· passive RFID identity on recovery\n· hand-placed, or drone-dropped\n\n"
   "Hardware we can actually build:\nESP32 + MR60BHA1 (0.4–1.5 m,\n~90 % respiratory accuracy) — an honest\nstand-in for low-band UWB, and we\nsay so out loud.", 11, INK, spacing=1.35)

# ═══════════════════════════════════════════════════ 8 · INNOVATION 2
s = blank()
head(s, "innovation 02", "The mesh is a sensor, and the packet carries evidence", "PRISM-Mesh — stigmergic relay: log-likelihood ratios instead of coordinates", CYAN)
rule(s)
box = s.shapes.add_shape(5, Inches(0.62), Inches(1.95), Inches(5.55), Inches(4.55))
box.fill.solid(); box.fill.fore_color.rgb = RGBColor(0x11, 0x1B, 0x26)
box.line.color.rgb = CYAN; box.line.width = Pt(1); box.shadow.inherit = False
tb(s, 0.85, 2.12, 5.1, 0.3, "64-BYTE EVIDENCE PACKET", 10.5, CYAN, bold=True)
tb(s, 0.85, 2.5, 5.1, 3.9,
   '{ "pod":"P07", "cell":"AB-1142",\n  "ch":"GEO", "t":1732.4,\n  "llr":1.35, "conf":0.62,\n  "health":{"bat":0.81,"snr":-114},\n  "extra":{"f0":2.4,"duty":0.31} }\n\n'
   "priority = log-LR × remaining-life prior\n\n"
   "→ the scarcest duty cycle is spent on\nthe survivor who matters most\n→ any phone can be a 2-hop relay:\nno app, no installer, no cooperation\n→ GPS-free relative ranging by LoRa RTT\n+ gossip (~1 m class, as Wi-Fi NAN/RTT\nachieves up to 15 m)", 11, INK, spacing=1.35, font="Consolas")
tb(s, 6.45, 1.95, 6.3, 0.3, "AND THE NETWORK ITSELF OBSERVES", 10.5, VIOL, bold=True)
tb(s, 6.45, 2.35, 6.4, 4.2,
   "A human body is water and salt — εᵣ ≈ 50–70 with high loss at 2.4 GHz. When a body moves inside a void,"
   " it perturbs the multipath field between two pods.\n\n"
   "That is channel 4: link-state tomography with a known geometry. Not a locator on its own — a"
   " likelihood ratio of 2–4, which is exactly what a combined posterior wants.\n\n"
   "And silence is a signal: the pattern of pods that stop hearing each other localises crush fronts"
   " and metallic shielding. The mesh's failure mode becomes telemetry.\n\n"
   "Falsifiable: if rain fading looks like breathing, FUSE down-weights this channel automatically —"
   " which is why we measure effective k instead of assuming it.", 11, INK, spacing=1.4)

# ═══════════════════════════════════════════════════ 9 · INNOVATION 3
s = blank()
head(s, "innovation 03", "Deliberation, not detection", "PRISM-Fuse — the only layer allowed to make a claim", VIOL)
rule(s)
pic(s, f"{FIG}/f6_evidence.png", 0.45, 2.30, 8.3)
tb(s, 8.95, 2.10, 3.8, 0.3, "THREE OUTPUTS", 10.5, VIOL, bold=True)
tb(s, 8.95, 2.46, 3.85, 4.6,
   "1 · A calibrated posterior\n   per cell — never a bare dot.\n\n"
   "2 · A decision gated by an explicit\n   budget: α = 10⁻³ false-alarm\n   probability per cell, β = 0.05\n   missed-survivor probability.\n\n"
   "3 · A certificate that a searched\n   cell is empty: P = 1 − mᵏ.\n   A 15 %-miss suite needs 4 passes\n   for 99.95 %, 5 for 99.99 %.\n\n"
   "This is the output that lets a\ncommander RELEASE a sector and\nreallocate the scarcest resource\non evidence, not on hope.", 11.5, INK, spacing=1.35)

# ═══════════════════════════════════════════════════ 10 · ARCHITECTURE
s = blank()
head(s, "system", "Four layers, one evidence algebra", "Every arrow carries a likelihood ratio, not a coordinate")
rule(s)
pic(s, f"{FIG}/f4_architecture.png", 1.93, 2.05, 9.35)
tb(s, 0.62, 6.85, 12.0, 0.55,
   "Terrain prior → p₀ per cell → pods emit evidence → mesh relays by information value → FUSE decides → Pursuit allocates the next team-hour. "
   "Runs offline on one laptop; one SQLite file is the whole state.", 10, MUTE)

# ═══════════════════════════════════════════════════ 11 · PRECISION
s = blank()
head(s, "false-positive elimination", "How we get to 0.99 precision without lying about it", "The prior carries the load; the channels carry the precision")
rule(s)
rows = [("prior p", "k = 1", "k = 2", "k = 3"),
        ("10⁻⁴", "0.0004", "0.002", "0.009"),
        ("10⁻³", "0.0045", "0.020", "0.084"),
        ("10⁻²", "0.044", "0.17", "0.48"),
        ("0.05", "0.19", "0.52", "0.83"),
        ("0.10", "0.33", "0.69", "0.91"),
        ("0.25", "0.60", "0.87", "0.97"),
        ("0.50", "0.82", "0.95", "0.99")]
x0, y0, h = 0.65, 2.1, 0.42
cw = [1.4, 1.5, 1.5, 1.5]
for i, row in enumerate(rows):
    xx = x0
    for j, cell in enumerate(row):
        col = MUTE if i == 0 else (RED if j == 1 and i >= 2 else (AMBER if j == 2 and i >= 3 else INK))
        if i == 0: col = CYAN
        tb(s, xx, y0 + i * h, cw[j], 0.35, cell, 13 if i else 10.5, col, bold=(i == 0 or j == 3 and i > 2))
        xx += cw[j]
tb(s, 0.65, y0 + 8 * h + 0.1, 6.0, 0.3, "PPV = p·TPR / (p·TPR + (1−p)·FPR)   ·   TPR 0.90", 10, MUTE, italic=True)
tb(s, 7.15, 2.1, 5.6, 0.3, "THE FOUR MECHANISMS", 10.5, GREEN, bold=True)
tb(s, 7.15, 2.5, 5.6, 4.3,
   "1 · Engineered independence — four channels\nobserve four different physical quantities, so a\nwarm rock cannot fire two of them.\n\n"
   "2 · SPRT stopping rule — α = 10⁻³, log A = 6.86,\nlog B = −2.99. Mean 4.0 samples to confirm,\n3.3 to clear. We stop probing the moment\nevidence is decisive.\n\n"
   "3 · Independence audit — FUSE reports the\nEFFECTIVE k. If two channels turn out correlated\nthe alert is downgraded, not hidden.\n\n"
   "4 · Calibration run — 20 seeded trials, reliability\ndiagram, Brier score, Wilson intervals on every\nTPR/FPR. We show the error bars.", 11, INK, spacing=1.35)

# ═══════════════════════════════════════════════════ 12 · OPEN DATA
s = blank()
head(s, "open data", "Three official feeds become three numbers on a rescue map", "Verified live from this workspace on 11 November 2026")
rule(s)
pic(s, f"{FIG}/f8_pipeline.png", 1.1, 2.26, 11.1)
tb(s, 0.62, 6.66, 12.0, 0.8,
   "SACHET RSS = HTTP 200, 98 active CAP 1.2 items (LGD district geocodes + polygon URL).  Overpass = 2,495 building ways in a 2 km² "
   "Mangaluru box.  IMD district warning = HTTP 401 without an API key, so the parser ships and the demo path uses SACHET, which needs no key.\n"
   "Architectural finding: INCOIS publishes tsunami, storm-surge, high-wave and swell-surge advisories into the SAME CAP-SACHET stream — one adapter covers both.",
   10, MUTE, spacing=1.35)

# ═══════════════════════════════════════════════════ 13 · DEMO SCRIPT
s = blank()
head(s, "execution", "The five-minute demo — including the negative result nobody else will show")
rule(s)
steps = [
    ("0:00", "The stakes", "The 72-hour curve. Wayanad: life-detection radar arrived on day 4.", RED),
    ("0:40", "The lie", "The PPV table. 'So we did not build a better detector.'", AMBER),
    ("1:20", "The compression", "LIVE Overpass + LIVE SACHET → 24 ranked void cells, not 10⁸ m³.", CYAN),
    ("2:10", "The pods", "Drop a pod into real rubble. Channel fires, LLR prints, SPRT crosses. THEN a warm water bottle and a phone go in — nothing fires.", GREEN),
    ("3:30", "The certificate", "Declare the sector safe: 99 % → 99.9 % → 99.99 %. Sector greys out, solver reallocates the team.", VIOL),
    ("4:20", "The rollback", "Kill the network mid-demo. Mesh relays, console reasons, nothing lost, resync on restore.", MUTE),
]
y = 1.9
for t, name, body, col in steps:
    tb(s, 0.65, y, 0.85, 0.3, t, 11, col, bold=True)
    tb(s, 1.55, y - 0.03, 2.15, 0.6, name, 12, col, bold=True)
    tb(s, 3.8, y - 0.03, 8.9, 0.75, body, 11, INK, spacing=1.3)
    y += 0.83
box = s.shapes.add_shape(5, Inches(0.62), Inches(6.85), Inches(12.05), Inches(0.45))
box.fill.solid(); box.fill.fore_color.rgb = RGBColor(0x16, 0x22, 0x2E)
box.line.color.rgb = GREEN; box.line.width = Pt(1); box.shadow.inherit = False
tf = box.text_frame; tf.margin_left = Inches(0.2); tf.margin_top = Inches(0.05)
p = tf.paragraphs[0]
r = p.add_run(); r.text = "If the schedule collapses, protect three artefacts: live SACHET→p₀, one pod giving one honest number through a real slab, and the certificate in the UI."
r.font.size = Pt(11); r.font.color.rgb = GREEN; r.font.name = "Calibri"

# ═══════════════════════════════════════════════════ 14 · BUILD PLAN
s = blank()
head(s, "feasibility", "24 hours, 3 engineers, three named checkpoints", "Every track owns a demo-visible artefact by hour 12 — and 4 hours of buffer are planned, not hoped for")
rule(s)
pic(s, f"{FIG}/f7_gantt.png", 0.4, 2.0, 12.55)

# ═══════════════════════════════════════════════════ 15 · IMPACT
s = blank()
head(s, "impact", "What the saved hours are worth", "Computed from measured swath × coverage, then compressed by the void prior")
rule(s)
pic(s, f"{FIG}/f9_impact.png", 0.96, 2.28, 11.4)
tb(s, 0.62, 6.80, 12.0, 0.62,
   "Per 200 m × 200 m sector: 41 team-hours naive → 2.6 h with the void prior → 1.1 h with three channels.   "
   "50 alerts at PPV 0.33 waste 402 team-minutes; at 0.99 they cost 6 minutes.   A pod costs ₹6–9k, not lakhs — which is what makes 'one pod per void' fundable by a district.",
   10.5, MUTE, spacing=1.35)

# ═══════════════════════════════════════════════════ 16 · LANDSLIDE (LIGHT)
s = blank()
head(s, "the harder hazard, attempted honestly", "Landslides: we did not predict them — we tried to hear them start",
     "One slide, one honest claim. PRISM remains the solution; this is the part of the problem we could not ignore.")
rule(s)
pic(s, f"{FIG}/f10_scope_compact.png", 0.62, 1.92, 12.1)
tb(s, 0.62, 5.16, 5.95, 0.3, "WHY LANDSLIDES ARE HARD", 10.5, RED, bold=True)
tb(s, 0.62, 5.52, 5.95, 2.4,
   "· Wayanad, ~02:00 — the flow arrived while people slept. No local\n"
   "  sensor existed on that slope; a district alert cannot warn a hill.\n"
   "· You cannot predict WHICH slope fails days out without geotechnical\n"
   "  instrumentation costing 10–50x more per site. We are not claiming that.\n"
   "· A debris flow is loud before it is visible: seismic + infrasound\n"
   "  (4–15 Hz) is detectable 17–138 s before the front arrives.", 10, INK, spacing=1.35)
tb(s, 6.85, 5.16, 5.9, 0.3, "WHAT WE ACTUALLY BUILT — SIREN", 10.5, CYAN, bold=True)
tb(s, 6.85, 5.52, 6.0, 2.4,
   "Two clocks: is the catchment saturated (published Western Ghats\n"
   "thresholds, 10-day antecedent), AND is the ground moving right now\n"
   "(4 co-located criteria). Neither alone may wake a village.\n"
   "Measured on synthetic traces: seismic-only false-alarms on 50% of\n"
   "non-events; conjunction + gate: 0%. ₹25,350 per protected hamlet.\n"
   "Run it yourself: python3 siren/detect.py", 10, INK, spacing=1.35)

# ═══════════════════════════════════════════════════ 17 · CLOSE
s = blank()
bar = s.shapes.add_shape(1, 0, 0, Inches(0.14), P.slide_height)
bar.fill.solid(); bar.fill.fore_color.rgb = AMBER; bar.line.fill.background(); bar.shadow.inherit = False
tb(s, 0.9, 0.85, 11.0, 0.3, "WHAT WE CLAIM  ·  WHAT WE DO NOT", 11, AMBER, bold=True)
tb(s, 0.85, 1.28, 5.7, 0.5, "We claim", 20, GREEN, bold=True)
tb(s, 0.9, 1.80, 5.6, 4.05,
   "· False-alarm probability bounded per cell\n  (α = 10⁻³, threshold visible in the UI)\n\n"
   "· Monotone precision — every independent\n  pass strictly improves PPV\n\n"
   "· Auditable negative evidence — a sector is\n  released with a pass count, not a shrug\n\n"
   "· Graceful degradation — when effective k\n  drops to 1 it refuses to auto-dispatch and\n  asks for one more orthogonal observation\n\n"
   "· Offline by construction, legal by\n  construction (IN865, duty-cycled)", 11.5, INK, spacing=1.35)
tb(s, 7.1, 1.28, 5.7, 0.5, "We do not claim", 20, RED, bold=True)
tb(s, 7.15, 1.80, 5.5, 4.05,
   "· 100 % detection in an open world.\n  Nobody can, and a team that claims it\n  has not read its own confusion matrix.\n\n"
   "· UWB radar ranges through saturated\n  rubble that the physics does not support.\n\n"
   "· That a 60 GHz module is low-band UWB.\n  It is an honest 24-hour stand-in, and the\n  architecture does not depend on it.\n\n"
   "· That this replaces dogs, FINDER-class\n  devices or structural specialists.\n  It tells them where to go first.", 11.5, INK, spacing=1.35)
box = s.shapes.add_shape(5, Inches(0.62), Inches(5.92), Inches(12.05), Inches(1.18))
box.fill.solid(); box.fill.fore_color.rgb = RGBColor(0x16, 0x22, 0x2E)
box.line.color.rgb = AMBER; box.line.width = Pt(1.25); box.shadow.inherit = False
tf = box.text_frame; tf.word_wrap = True; tf.margin_left = Inches(0.25); tf.margin_top = Inches(0.12)
p = tf.paragraphs[0]
r = p.add_run(); r.text = "PRISM  ·  अभेद्य means impenetrable."
r.font.size = Pt(15); r.font.bold = True; r.font.color.rgb = AMBER; r.font.name = "Calibri"
p2 = tf.add_paragraph()
r2 = p2.add_run(); r2.text = ("The rubble is not impenetrable to us — we put the sensor inside it. The clock is what is impenetrable, "
                              "which is why we spend the first hour shrinking the search instead of flying it.")
r2.font.size = Pt(12.5); r2.font.color.rgb = INK; r2.font.name = "Calibri"

P.save("abhedya/PRISM_pitch.pptx")
print("slides:", len(P.slides.__iter__.__self__._sldIdLst))

s = blank()
bar = s.shapes.add_shape(1, 0, 0, Inches(0.14), P.slide_height)
bar.fill.solid(); bar.fill.fore_color.rgb = AMBER; bar.line.fill.background(); bar.shadow.inherit = False
tb(s, 0.9, 0.85, 11.0, 0.3, "WHAT WE CLAIM  ·  WHAT WE DO NOT", 11, AMBER, bold=True)
tb(s, 0.85, 1.28, 5.7, 0.5, "We claim", 20, GREEN, bold=True)
tb(s, 0.9, 1.80, 5.6, 4.05,
   "· False-alarm probability bounded per cell\n  (α = 10⁻³, threshold visible in the UI)\n\n"
   "· Monotone precision — every independent\n  pass strictly improves PPV\n\n"
   "· Auditable negative evidence — a sector is\n  released with a pass count, not a shrug\n\n"
   "· Graceful degradation — when effective k\n  drops to 1 it refuses to auto-dispatch and\n  asks for one more orthogonal observation\n\n"
   "· Offline by construction, legal by\n  construction (IN865, duty-cycled)", 11.5, INK, spacing=1.35)
tb(s, 7.1, 1.28, 5.7, 0.5, "We do not claim", 20, RED, bold=True)
tb(s, 7.15, 1.80, 5.5, 4.05,
   "· 100 % detection in an open world.\n  Nobody can, and a team that claims it\n  has not read its own confusion matrix.\n\n"
   "· UWB radar ranges through saturated\n  rubble that the physics does not support.\n\n"
   "· That a 60 GHz module is low-band UWB.\n  It is an honest 24-hour stand-in, and the\n  architecture does not depend on it.\n\n"
   "· That this replaces dogs, FINDER-class\n  devices or structural specialists.\n  It tells them where to go first.", 11.5, INK, spacing=1.35)
box = s.shapes.add_shape(5, Inches(0.62), Inches(5.92), Inches(12.05), Inches(1.18))
box.fill.solid(); box.fill.fore_color.rgb = RGBColor(0x16, 0x22, 0x2E)
box.line.color.rgb = AMBER; box.line.width = Pt(1.25); box.shadow.inherit = False
tf = box.text_frame; tf.word_wrap = True; tf.margin_left = Inches(0.25); tf.margin_top = Inches(0.12)
p = tf.paragraphs[0]
r = p.add_run(); r.text = "PRISM  ·  अभेद्य means impenetrable."
r.font.size = Pt(15); r.font.bold = True; r.font.color.rgb = AMBER; r.font.name = "Calibri"
p2 = tf.add_paragraph()
r2 = p2.add_run(); r2.text = ("The rubble is not impenetrable to us — we put the sensor inside it. The clock is what is impenetrable, "
                              "which is why we spend the first hour shrinking the search instead of flying it.")
r2.font.size = Pt(12.5); r2.font.color.rgb = INK; r2.font.name = "Calibri"
