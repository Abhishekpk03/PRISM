# PRISM — Solution Description

**INNOVEX 2026 · Season 02 · NSS IT Wing · Nitte University, Deralakatte**
**Problem Statement 5 — Project Abhedya · Focus Area 03: Search & Rescue**

---

## 1. The solution in one page

**PRISM is a decision pipeline, not a sensor.** It takes data India already holds — municipal
tax records, sanctioned plans, rental listings, structural audits, and the collapse geometry published
in rescue doctrine — joins it, computes it, and returns a ranked, time-aware rescue plan with an
accuracy figure attached to every claim.

It answers the five questions a commander actually has, in the order he has them:

1. **Which building.** A standing band for every building in the queue, from records alone.
2. **How it fell.** A mechanism posterior over six known collapse classes, or an explicit refusal.
3. **Where the pockets are.** An enumerated void field — zone, floor, volume, clearing effort.
4. **Who is inside and are they alive.** Expected persons per pocket, and a survival clock.
5. **Which team, in what order.** Allocation in expected lives per team-hour, with ETAs.

The output is not a dashboard and not a map. It is **one page a commander can act on at 03:00**,
and it changes by itself as the night goes on.

> The single idea that makes this different: **PRISM refuses to answer when the evidence does not
> support an answer.** Where accuracy is unattainable it returns UNCERTAIN and falls back to a
> survivable-void prior. A visible gap is worth more than a confident guess, because a commander
> can act around a gap and cannot act around a lie.

---

## 2. Five design laws

These are not slogans. Each one is enforced in code and tested.

**Law 1 — Records before sensors.** The cheapest data that already exists beats the most
sophisticated data that does not. A municipal record and a rental listing, joined on GPS, yield a
load ratio in seconds for free. Satellite is tier six of seven, not tier one.

**Law 2 — Every number carries its bias.** Each assumption declares the direction it would push
the answer. The pipeline prints an eight-item self-doubt report at the end of every run, including
one entry admitting the reference case was tuned and therefore validates nothing.

**Law 3 — Refuse rather than guess.** Mechanism returns UNCERTAIN when no class exceeds 0.60 or
the structure type is outside the vocabulary. Sensor silence is never treated as proof of absence.
The word *dead* cannot be printed.

**Law 4 — Time is a variable, not a timestamp.** Survival is a function of the hour the team
arrives, not of the hour the report was written. The ranking therefore changes on its own.

**Law 5 — Every claim has a metric, or it does not go in the deck.** Section 5 exists because
"95% accurate" is meaningless until you say accurate at what.

[[FLOW]]

---

## 3. Six failures, nine components

The problem statement names six failure points. Every one is answered by a named component, and
every component has an owner, an input contract and a stated failure mode.

| Failure | What it was | Answered by | How |
|---|---|---|---|
| **F1** | City cannot rank 30.7 lakh buildings | C1, C2 | Record spine + load-ratio band |
| **F2** | Mechanism inferred on arrival, qualitatively | C4 | Bayesian model averaging + refusal gate |
| **F3** | Survivable pockets never enumerated | C5 | Void field from mechanism geometry |
| **F4** | Allocation ignores the clock and the rate | C6, C7 | Survival clock + lives-per-team-hour |
| **F5** | Records that answer everything are never joined | C1 | Declared-versus-built join on GPS |
| **F6** | The only instant channels are unwired | C3, C8 | Listing census, last-gasp sensor, evidence ledger |

Two cross-cutting components complete the set: **C9** (evidence ledger and audit trail) and
**C10** (sensing integration, with its physical limits stated).

---

## 4. The components

### C1 · Record spine and the declared-versus-built join

- **Input.** Municipal property record (UPIC, declared covered area, declared floors, use, age); sanctioned plan where one exists; rental or PG listing (advertised `total_floors`, beds, area, GPS).
- **Rule.** Join on the 15-digit UPIC and on GPS proximity. Where the declared floor count and the advertised floor count disagree by two or more, emit a **load-ratio flag**. Never emit a legal verdict — the output is *flag for inspection*, because records may be stale and buildings may have been regularised.
- **Output.** A per-building record with `declared_floors`, `observed_floors`, `design_occupancy`, `observed_occupancy`, and a verifiability flag.
- **Why this is the strongest component.** MCD's own 3D-mapping pilot exists to catch "under-reported built-up area — paying tax for fewer floors". The mismatch is the municipality's stated problem. PRISM asks a rescue question of it: a sanctioned G+1 advertising six floors is a load ratio of 3.0, and load ratio predicts mechanism.
- **Failure mode.** 70% of surveyed Delhi PG plans are untraceable. Handled by degrading to a listed-floor-only band and saying so.

### C2 · Standing band

- **Input.** The C1 record plus structure type, year, and any corrosion survey.
- **Rule.** Load ratio is floors × density, kept separate so nobody hides which one drove it. Demand over capacity is the floor ratio against a 1.5 foundation margin. Fragility is lognormal with β = 0.35. Standing probability is the greater of the gravity and seismic terms.
- **Output.** A band — RED, AMBER, GREEN — with the load ratio printed and its verifiability stated.
- **What it is not.** Not a forecast. The band's job is to order a queue for inspection, and to seed the mechanism prior if that building later collapses.
- **Failure mode.** Brittle shear failure has no meaningful precursor. C2 never claims to prevent a collapse; it claims to sequence inspections.

### C3 · Satellite auditor

- **Input.** Free optical imagery, Open Buildings 2.5D heights, and post-event debris extent.
- **Rule.** Pre-event: audit footprints and height trend at city scale. Post-event: compute the ratio of debris area to footprint area, which separates a **vertical** family (debris stayed in place) from a **lateral** family (debris thrown outwards). That single discriminator is all a 10 m sensor can honestly contribute to mechanism.
- **Output.** A debris family with a confidence, and a queue of buildings flagged for inspection.
- **The arithmetic that governs it.** A 46 m² plot is **0.46 of one Sentinel-2 pixel.** The sixth floor of the reference case is physically invisible to the free sensor. The component reports `sub_pixel: true` and refuses to grade that building rather than guessing.
- **Latency, stated plainly.** Free optical revisits every ~5 days; SAR every 6–12 days; damage maps arrive 1–6 days later at roughly 100 m and cannot separate heavily damaged from destroyed.

### C4 · Mechanism engine

- **Input.** Structure type, element removed, floors above, load ratio, debris family, last-gasp packet.
- **Rule.** Bayesian model averaging over six documented mechanisms, each with published void geometry and fatality rate. Scores combine evidence channels with declared weights; the posterior is the normalised exponential of the score.
- **The refusal gate.** If the maximum posterior is below 0.60, **or** the structure type is outside the six-class vocabulary, the output is `UNCERTAIN / novel` and the void field falls back to a survivable-void prior — lean-to, perimeter, stairwell, beside heavy furniture.
- **Output.** A posterior over six classes, a lead class, a confidence, and a novelty flag.
- **Why no trained classifier.** No labelled rubble dataset exists at any scale. Claiming one in 24 hours would be a lie; a rule-based prior with a stated uncertainty is the honest instrument.
- **Failure mode.** The Satya Niketan case returns pancake at 0.98 — but that case was used to develop the model, so the number is a sanity check, not a validation.

### C5 · Void field

- **Input.** Mechanism posterior, floors, and the zone taxonomy.
- **Rule.** Each mechanism predicts where pockets physically sit. A V-shape puts pockets at both exterior walls; a lean-to puts one large pocket under the raised end; a pancake leaves slivers between slabs. These become a distribution over six zones. **Each pocket draws its mechanism from the whole posterior, not the lead class** — because if the call is 60/40, the pile really is mixed.
- **Output.** Pockets with zone, floor, volume, clearing effort in team-minutes, search probability, and collapse risk.
- **Failure mode.** Zone priors are expert-derived, not measured. Declared in the self-doubt report.

### C6 · Occupancy and survival clock

- **Rule.** Expected trapped = heads × probability present at that hour × fraction of the building that came down, where the fraction is mechanism-dependent. People are distributed across pockets as a **Poisson mean**, so one pocket can hold three people rather than a coin flip. Survival is the mechanism's fatality rate subtracted from one, multiplied by the survival curve at the hour the team would arrive.
- **The clock.** Survival of the entrapped runs 91% at 30 minutes, 81% at 1 day, 36.7% at 2 days, 19% at 4 days. The curve is interpolated piecewise rather than smoothed, because the cliff between day one and day two is the single most decision-relevant feature and smoothing would erase it.
- **Output.** A per-pocket headcount and a survival value that is a function of time.
- **Failure mode.** Beds are not heads and listings lag by months, so the count is a floor, not an estimate. Said out loud.

### C7 · Tasking and allocation

- **Rule.** Priority is expected lives per team-hour:

  `ELSE = λ × s(t) × d_dig ÷ effort_hours × (1 − R)`

  where λ is expected persons, s(t) survival at arrival, d_dig the probability of finding someone by physically searching that pocket, and R the risk of further collapse. Teams are assigned greedily to the highest score and the whole ranking is recomputed every cycle.
- **The distinction that matters.** `d_dig` is the probability of finding someone **by digging** — 0.57 to 0.95 — and is not the remote sensor's detection probability. Conflating the two was a real defect that under-counted expected lives by a factor of three.
- **Output.** A ranked dig list with ETAs, an expectant list carrying a re-triage timer, and an explicit statement of which pockets cannot be reached inside the horizon.
- **Failure mode.** Where R is high the score is discounted but entry is not yet hard-blocked. Known, listed, unfixed.

### C8 · Sensing integration, with its limits

- **What is used.** Passive phone census over the footprint (uplink energy and probe sniffing, receive-only) as an occupancy confirmation; and a last-gasp accelerometer in the structural element as the only genuinely instant channel — impact count approximates pancake count, duration separates simultaneous from progressive failure.
- **What is used if available.** Through-rubble radar of the FINDER class, which detects breathing chest motion through 30 ft of rubble, and heartbeat chest motion of 0.2–0.5 mm. It returns a **motion point at depth**, never an image of a person.
- **What is rejected, and why.** Muon tomography needs 40 days of exposure and images density, not people. Sub-millimetre robot swarms cannot traverse rubble: a mm³ mote holds about one joule, enough to listen for 28 hours but not to walk for 17 minutes, and RF penetrates only 0.171 m at 866 MHz. Both are refused on physics, and the refusal is itself a credibility asset.
- **Legal constraint.** An IMSI catcher is interception infrastructure. PRISM specifies **passive receive only** — no tower impersonation — and the demo is built to run that way.

### C9 · Evidence ledger

- **Rule.** Every claim written to the plan is stored with its inputs, its weights, its timestamp and its author. Every expectant decision carries a revisit time. Every human override is logged with a reason.
- **Output.** A defensible record of why a pocket was cleared, ranked, or deferred — which is exactly what no current system produces.
- **Why it matters.** It converts rescue decisions from unwritten experience into auditable evidence, and it is what makes the accuracy claims in Section 5 testable after the fact.

### C10 · The clearance algebra

- **Rule.** A pocket is declared clear only on **k independent confirmations**, and the resulting positive predictive value is computed and printed.

| Confirmations (k) | PPV at prior 1e-3 | at 1e-2 | at 0.1 | at 0.5 |
|---|---|---|---|---|
| 1 | 0.0045 | 0.0435 | 0.3333 | — |
| 2 | — | — | 0.6923 | — |
| 3 | — | — | **0.9101** | **0.9891** |

- **Reading the table.** A single confirmation is worthless when the prior is low — one positive at a 1-in-1,000 prior gives 0.45% confidence. Three independent confirmations at a 10% prior give 91%. This is why clearance must be k-of-n, and why stating k is not optional.
- **The cost of that confidence.** To reach 0.99 PPV at a 0.01 prior the required false-positive rate is 9.2 × 10⁻⁵. That is achievable algebraically and is the correct target for the ledger, not a slogan.

---

## 5. Reaching 95%: what accuracy means here

"95% accurate" is not a property of a system. It is a property of a metric. PRISM defines nine,
and is explicit about which can reach 95% and which cannot.

| Claim | Metric | Path to ≥95% | Verdict |
|---|---|---|---|
| A pocket declared clear really is clear | PPV of Clear verdict | k-of-3 independent confirmations → **0.9101 at prior 0.1, 0.9891 at prior 0.5** | **Achievable** |
| A breathing casualty is detected | POD | FINDER-class POD ≈ 0.80; three independent passes → **1 − 0.2³ = 0.992** | **Achievable** |
| The plan is reproducible | Determinism | same inputs, same plan; 10/10 adversarial tests | **Achieved, 100%** |
| An over-built property is flagged | Recall on audit | declared-versus-built join against MCD ground truth | **Achievable at city scale** |
| The ranking puts a casualty in the top three | Hit@3 | back-test on 30 historical collapses; not yet run | **Unproven** |
| Occupancy within ±25% | MAPE | phone census plus listing refresh | **Plausible, unproven** |
| Mechanism named correctly | Top-1 accuracy | needs a labelled rubble dataset that does not exist | **Not achievable** |
| Survival estimate calibrated | Brier / ECE | needs an outcome registry | **Not achievable yet** |
| Collapse prevented | Incidence | brittle failure has no precursor | **Out of scope by design** |

**The doctrine that follows from the table.** There are only three honest ways to move a number
toward 95%: **redundancy** (buy independent confirmations — k-of-n), **better prior data** (records
before sensors), and **refusal** (when neither works, return UNCERTAIN instead of an estimate).

The third is the invention. A system that says nothing when it does not know converts an invisible
error into a visible gap, and a visible gap is something a commander can plan around. **PRISM is
designed so that its failures are legible.** That is a stronger guarantee than a nominal accuracy
figure, and it is the one thing here that a rival cannot copy by adding sensors.

---

## 6. Three novel solutions

Each is stated with the prior art it must survive, because overstating novelty is how this work
fails review.

### N1 · Records-to-mechanism bridge

- **The idea.** Municipal declared floors and actual occupancy, joined against advertised floors at the same GPS, produce a **load ratio**. Load ratio, element removed, and floors above predict the collapse mechanism. Mechanism predicts where the voids are. No rescue system today uses a tax record to predict a rubble geometry.
- **Prior art it survives.** FEMA P-154 and India's RVS score buildings for inspection. Neither is wired to occupancy, and neither produces a rescue output. **RVS tells an engineer what to inspect; it does not tell a commander what to expect.**
- **Why it is rarely implemented.** It requires joining datasets owned by different departments for a purpose neither department has. The municipality keeps records to collect tax; the fire service keeps no records at all.

### N2 · Computable void prior with a live survival clock

- **The idea.** Void geometry per mechanism is published doctrine, but only in prose. PRISM turns it into a distribution over zones, distributes people across it, and ranks by expected lives per team-hour — with survival as a function of the hour the team arrives, so the order changes without new input.
- **Prior art it survives.** FEMA USAR scores a **building**, and scores it on arrival. INSARAG marks voids during the search. Search theory gives the priority index and ReSTART gives the allocation rule, but neither has an input stream. **The maths is solved; the data pipe is not built.**
- **Why it is rarely implemented.** It needs a record for every building, which is exactly what F5 says does not exist. PRISM's answer is to build the record from the cheapest available tier and to mark every gap.

### N3 · Clearance with a stated error rate and an evidence trail

- **The idea.** Every clearance decision carries k, the confirmations behind it, the resulting PPV, and a full evidence chain. Nothing in the field does this.
- **Prior art it survives.** INSARAG has a Clear mark and FEMA defines a null search as "no victims". Both are doctrine and neither attaches a probability. In one post-earthquake survey only **47.4%** of responders correctly identified the Clear marking — which is a doctrine-adoption problem, not a knowledge problem.
- **Why it is rarely implemented.** It converts a judgement into a number, and numbers can be challenged. That is the point.

---

## 7. What the operator actually uses

| Surface | What it gives | When |
|---|---|---|
| Building queue | ranked list with RED/AMBER/GREEN and load ratio | pre-event, continuous |
| Mechanism card | posterior, confidence, novelty flag | on collapse |
| Pocket list | zone, floor, people, survival, effort, ELSE | first 10 minutes |
| Dig order | ETAs, which team, what order | continuously updated |
| Expectant list | re-triage timer per pocket | every cycle |
| Shortfall statement | what cannot be reached in time | every cycle |
| Self-doubt report | eight assumptions and their bias direction | every run |
| Evidence ledger | why every decision was made | for the inquiry |

The whole surface is one page. Anything that does not change a decision is not on it.

---

## 8. Implementation process

Five phases. Each has an exit gate and — deliberately — a **kill criterion**, because a plan
without a stop condition is a wish.

| Phase | Deliverable | Exit gate | Kill criterion |
|---|---|---|---|
| **0 · 24 h** | pipeline, 9 components, 10 adversarial tests, this document | 10/10 tests, reproducible demo in 5 min | any test that cannot pass |
| **1 · weeks 1–4** | record spine on one ward; join against UPIC and listings | 1,000 buildings scored, verifiability flag correct | join rate below 40% |
| **2 · weeks 5–8** | blind back-test on 10 historical collapses | Hit@3 computed and published, tuned or not | Hit@3 below 0.60 |
| **3 · weeks 9–12** | last-gasp node prototype; passive census prototype | packet survives from a test pile to a receiver | no packet, no node |
| **4 · shadow pilot** | runs beside one SDRF unit, generates plans nobody acts on | commander finds the ranked list useful unprompted | plans ignored for 20 consecutive events |

**Phase 2 is the one that decides the project.** The protocol is pre-registered: the model is frozen
before the test cases are opened, every case is scored whether it flatters the design or not, and
the result is published even if Hit@3 is 0.4. A back-test you can tune is not a back-test.

---

## 9. Validation and falsification

- **Blind replay.** Historical collapses with known outcomes are replayed with the outcome withheld. The reference case used to develop the model is excluded from the test set permanently — it is contaminated.
- **Ablation.** Remove the records and measure the loss; remove the sensor and measure the loss. If a component earns nothing it gets cut.
- **Attack.** Ten adversarial checks currently pass, covering unit consistency, scheduler safety, posterior normalisation, survival monotonicity, unknown structure types, stale records, sensor silence, forbidden output, capacity shortfall, and the value-of-information regime.
- **A result we did not want.** Our own confirm-before-dig feature loses **0.44 lives** where records exist and gains **0.61** where they do not. The headline is therefore the records, not the sensor. That finding is in the deck and in this document because pretending otherwise would be the beginning of the end of the project.

---

## 10. Risks and mitigations

| Risk | Likelihood | Mitigation |
|---|---|---|
| Records too sparse to be useful | high | degrade to listed-floor band and say so; census as fallback |
| Zone priors wrong for unusual stock | medium | refusal gate plus mandatory override logging |
| Operators do not trust a ranked list | medium | shadow-mode pilot; the plan never removes human judgement |
| Legal exposure from "illegal" flags | medium | output is *flag for inspection*; no legal verdict is ever printed |
| Ethical exposure from expectant decisions | medium | expectant is a resource judgement with a re-triage timer, never a death verdict |
| Model tuned to one case | high | case excluded from validation; kill criterion at Phase 2 |
| A rival claims the same thing | medium | publish the ablation and the refusal gate; those are hard to copy convincingly |

---

## 11. Ethics, legality and data

- **No legal verdicts.** A load-ratio mismatch produces *flag for inspection*. Records may be stale, buildings may be regularised, and defamation is a real risk.
- **Passive sensing only.** Receive-only uplink energy and probe sniffing. No tower impersonation, no interception, and the demo is built to prove it.
- **No death verdicts.** The category is *expectant*, it carries a re-triage timer, and the word *dead* is blocked in output — enforced by a test, not a policy.
- **Human override, logged.** The system advises. Every override is recorded with a reason, which protects both the commander and the evidence trail.
- **Data minimisation.** Occupancy is stored as a band and a count, not as identities.

---

## 12. Boundaries

**In scope:** structural collapse, search and rescue, decision support, open-data integration,
offline operation, accuracy instrumentation.

**Not claimed:** collapse prediction, real-time satellite detection, trained mechanism
classification, validated survival calibration, and any output that states a person is dead.

**Out of scope for this document:** product development, hardware manufacture, and unit economics.
This describes the solution and how it would be implemented, not a product build.

---

## 13. Where this goes next

The 24-hour version is a decision engine fed by records. The next step is not more sensors — it is
**one ward of records and ten blind replays**, because that is the only thing that can turn
"unproven" into a number in the table in Section 5. Everything else in this design is already
built and already attacked; the remaining work is evidence.

> The claim we will stand behind: **PRISM does not invent void-finding, triage or allocation.
> It makes the doctrine computable, quantified and time-aware — and it makes its own failures
> visible.**

**Traceability.** Every figure in this document is generated by `abhedya/prism/pipeline.py` and
reproduced in `abhedya/prism/PIPELINE.md`; the adversarial results come from
`abhedya/prism/redteam.py`; and the sources underlying the doctrine and field data are listed in
full in `abhedya/PRISM_Problem_Statement.pdf`. Document, code and slides read the same values, so
they cannot disagree.
