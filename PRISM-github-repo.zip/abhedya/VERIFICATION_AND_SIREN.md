# Verification report + SIREN one-pager
*Independent re-derivation, 11 Nov 2026. Script: `research/verify.py` → 51/51 checks pass.*

---

## Part 1 — Verification

### 1.1 Arithmetic: re-derived from scratch, not re-read

All 51 headline numbers were recomputed with independent code paths (`research/verify.py`), not by
re-running the original analysis. **51/51 pass.** Groups checked:

| Group | Examples | Result |
|---|---|---|
| PPV algebra | 1e-3→0.0045, 0.1&k2→0.692, 0.5&k3→0.989 | ✅ |
| Required FPR for 0.99 PPV @prior 0.01 | 9.09e-05 | ✅ |
| Required per-channel LR | 989,901 (k=1), 100 (k=3) @prior 1e-4 | ✅ |
| SPRT thresholds | A=6.86, B=−2.99, E[n]=4.0 / 3.3 | ✅ |
| Coverage certificate | m=.15: 4 passes→99.95%, 5→99.99% | ✅ |
| Void accounting | 60.5 m³ → 24.2 cells; 6.2 orders | ✅ |
| Thermal SNR decay | 7.96 → below floor at 24 min | ✅ |
| RF depth through saturated rubble | BLE 0.63 m, LoRa 2.75 m, UWB-low 0.75 m | ✅ |
| Skin depth in fresh water | 0.171 m @866 MHz, 0.103 m @2.4 GHz | ✅ |
| Drone swath/throughput | 17.2 m, 11.0 ha/sortie @30 m | ✅ |
| Cost of false alarms | 402 team-min @PPV .33; 6 @PPV .99 | ✅ |
| Survival curve (Weibull k=2.5, T=60.4 d) | 90.5% / 56.9% / 21.2% at 24/48/72 h | ✅ inside published ranges |
| Optical GSD & recognition limit | 2.7 cm/px @30 m; 69.7 m limit | ✅ |

### 1.2 Two errors found — both were mine, in the *labeling*, not the maths

1. **Thermal SNR time axis.** I had been quoting the curve at t = 30/60 min, but the array is
   subsampled every 10 min, so those entries are t = 20/40 min. The curve and the "blind at 24 min"
   figure were always correct; the point labels in my prose were off by one index.
2. **Survival @24 h.** The fitted curve gives **90.5 %**, fractionally above the published 90 % upper
   bound. Immaterial, but the deck should say "≈90 %" and "fitted to published cohorts", never a
   false precision.

### 1.3 Live feeds: re-tested today

| Feed | Result |
|---|---|
| NDMA SACHET CAP RSS | **HTTP 200, 98 active CAP items** — unchanged, and no API key needed |
| OSM Overpass (POST, 2 km² Mangaluru box) | **HTTP 200, 2,530 building ways** |
| IMD district warning | **HTTP 401** — still key-gated; the SACHET demo path remains the right call |
| SACHET `FetchPolygonXMLFile` | 403 (as documented) → LGD-code fallback is the designed route |

### 1.4 The claim classes — and what each is actually worth

This is the part that matters most for a pitch, because mixing these classes is how teams get
dismantled by a sharp judge.

| Class | Claims | Status |
|---|---|---|
| **A · Arithmetic** | Every PPV, LR, SPRT, coverage, void, attenuation, cost number | **Solid.** Provable in front of them in 30 s |
| **B · Published literature** | Survival 74–90 %/24 h; FINDER 30 ft; UWB 1.2–1.7 m wet rubble; mmWave 0.2–0.5 Hz chest motion; LoRa IN865 legal limits | **Solid, correctly attributed** |
| **C · Modelled by us** | 41 h → 1.1 h sector clearance; 2.6 h time-to-confirmation; effective-k in the field | **Defensible but MODELLED.** Say the word "modelled" out loud |
| **D · Assumed / unvalidated** | Void fraction 5–12 %; pod survival on drop; 7-day battery; that a pod lands in the right void | **Weakest link.** Exposed as parameters, listed as unknowns |

**One correction to my own earlier framing, which I want on the record:** last message I said 60 GHz
was a poor choice for through-rubble sensing. Verification of the propagation data says something
more precise — **60 GHz is fine (even advantageous) for in-void sensing under ~1.5 m, and hopeless
through 20 cm of brick (−15 to −20 dB) or through wet soil.** So the honest statement is not
"bad sensor", it is **"good sensor with a hard placement constraint"** — which is exactly why the
architecture leans on the vibration/tap channel and on throwing six cheap pods.

---

## Part 2 — SIREN
### Seismic–Infrasonic Rainfall-triggered Early Notification
*A small idea, done properly — and deliberately the safest 24-hour win in the brief.*

### 2.1 Why this one

Landslides kill in the Western Ghats because **the mountain gives no notice**. The 30 July 2024
Wayanad flow arrived around 2 a.m. while people slept. Nobody was warned, because nothing was
listening.

But here is the uncomfortable truth: **a debris flow is loud before it is visible.** It generates
characteristic seismic vibration and low-frequency infrasound (4–15 Hz) that instruments pick up
**17–138 seconds before the front reaches the sensor**, and infrasound can carry kilometres. The
research stations that do this (Illgraben, Lattenbach, MAMODIS) are permanent installations costing
lakhs, sitting on Alpine check dams. **Nobody has built the ₹6,000 village version, in India, fused
with rainfall thresholds.**

### 2.2 The idea: two clocks, one alarm

The core insight is that a landslide gives you **two different kinds of warning time**, and almost
everyone uses only one:

| | **Tier 1 — the slow clock (hours)** | **Tier 2 — the fast clock (seconds)** |
|---|---|---|
| **Watches** | rain + antecedent saturation | ground vibration + infrasound |
| **Physics** | Western Ghats rainfall ID thresholds | 4–15 Hz mass-movement signature |
| **Lead time** | **6–24 hours** | **17–138 s at the sensor**, minutes downstream |
| **Cost of a false alarm** | moderate (needless evacuation) | severe (trust collapses) |
| **Where it comes from** | IMD forecast + node rain gauge + soil moisture | co-located geophone + infrasound mic |

**The published thresholds are already specific to this region**, which is what makes Tier 1 real
rather than hand-wavy:

- Western Ghats regional ID fit: **I = 28.01 D^−0.641** → ≈ **3.65 mm/h, ~88 mm in 24 h**
- Kerala local lower-boundary fit: **I = 1.82 D^−0.23** → ≈ **21 mm/24 h** as the lowest observed trigger
- The three Kerala landslides of 16 Oct 2021 were all triggered by **266 mm in 24 h** (5-day antecedent only 109.9 mm)
- The 2018–20 Kerala events: **373 mm/24 h** with **586 mm in the preceding 3 days**
- **Antecedent matters more in the Ghats than in the Himalaya** — 10-day antecedent rainfall is the critical condition, because of thick laterite soils

So Tier 1 is: *has this slope been drinking for ten days, and is it about to be hit hard?* That is a
computable, region-specific, publicly-derivable question.

### 2.3 The trick that makes it trustworthy

**Tier 2 only escalates to a full alarm if Tier 1 says the catchment is primed.**

This is the *same* architecture as PRISM — a claim is only published when independent evidence
conjuncts — and it solves the one problem that kills every community warning system: **crying wolf.**
A rockfall next to a node in dry weather is rejected. The same signature during a 200 mm day with a
saturated catchment escalates immediately.

The literature supports exactly this: co-located infrasound + seismic detection across nine test
sites over 2013–2016 detected **all** larger debris flows with only **seven false alarms in three
years** — and the authors' explicit conclusion is that the *combination* is what suppresses false
alarms, whereas either sensor alone does not.

### 2.4 What it actually buys, in seconds

Detect a flow at the top of the path, and warn the hamlet below. Pure arithmetic:

| Distance of village from the node | @5 m/s | @8 m/s | @10 m/s |
|---|---|---|---|
| 300 m | 60 s | 38 s | 30 s |
| 500 m | 100 s | 62 s | 50 s |
| 1,000 m | **200 s** | 125 s | 100 s |
| 2,000 m | **400 s** | 250 s | 200 s |
| 3,000 m | 600 s | 375 s | 300 s |

At 8–10 m/s a front covers **480–600 m in a minute**, so distance from the node is the whole game —
which means the deployment rule is simple and defensible: **put the node high on the path, not in
the village.**

### 2.5 The hardware (and the honest cost)

A node is a geophone + infrasound sensor + ESP32 + LoRa 865 MHz + 5 W solar + enclosure:

| Part | ₹ |
|---|---|
| geophone | 900 |
| infrasound sensor (or electret + low-pass front end) | 1,500 |
| ESP32 | 450 |
| LoRa module (SX1276, IN865) | 1,300 |
| solar + battery + charge controller | 1,200 |
| enclosure, mast, cable | 600 |
| **per node** | **≈ 5,950** |

A hamlet's path needs maybe 3 nodes + 1 siren/gateway node. **Under ₹25,000 to instrument one
landslide path.** That is a Gram Panchayat-scale budget, which is the whole point.

### 2.6 Last-mile: the part everyone forgets

A warning nobody hears at 2 a.m. is not a warning. Three delivery legs:

1. **Local siren** at the hamlet node — loud, powered, no phone needed, works when everyone is asleep.
2. **LoRa → panchayat gateway** which relays onward even with no internet (the PRISM mesh stack, reused).
3. **CAP-format alert into SACHET/SMS** via the gateway when a link exists — this is where the
   required NDMA/IMD datasets stop being decoration and become the dissemination channel.

Plus one social layer that matters more than any radio: **a designated night-watch volunteer** who
owns the phone number the node texts. Technology without a person is a science project.

### 2.7 The 24-hour demo (this is the strong part)

| Minute | What the judges see |
|---|---|
| 0:00 | Live IMD/SACHET pull + the Western Ghats threshold curve; current 10-day antecedent plotted → "this slope has been drinking" |
| 0:40 | Shake a tray of rubble/metal sheet: geophone + infrasound fire, **Tier-2 detection in under a second** of processing |
| 1:20 | LoRa alarm reaches the "village" node **300 m away across the corridor** → siren sounds. Physical. Loud. Unmissable |
| 2:30 | **The false-alarm test:** drop a rock next to the node in a "dry catchment" configuration → **nothing fires**, because Tier 1 isn't primed. Then flip the catchment to "saturated" and repeat → it fires |
| 3:30 | Warning-time calculator: drag the village 500 m → 2 km and watch the lead time go 100 s → 400 s |
| 4:20 | Cost slide: ₹5,950/node, ₹25,000 per path, versus a permanent research station at lakhs |

**Every step is real, cheap, and has a ~90 % chance of working on the night** — versus PRISM's
60 %-risk breathing-detection moment. That asymmetry is the honest reason to consider switching.

### 2.8 Weaknesses, stated plainly

| Weakness | Assessment |
|---|---|
| You **cannot** demonstrate a real landslide in 24 h | Correct. Demo the *signal processing* on simulated shaking + published event waveforms, and say so. Judges respect the distinction |
| Very fast, very close flows give <60 s | Real limitation. Mitigation is siting the node high on the path — the table above makes this explicit rather than hidden |
| False alarms destroy trust permanently | This is why the Tier-1 gating exists; a false alarm is still possible and must be designed for with graded alerts ("prepare" vs "evacuate") |
| Nodes get stolen, damaged, unmaintained | The real deployment risk, and it is social, not technical. Needs panchayat ownership and annual servicing built into the design |
| Antecedent data | Rain gauge at the node + IMD gridded rainfall; gaps filled by satellite (GPM/IMERG-class) — good, not perfect |
| Power | 5 W panel + LiFePO4 sized for 7 days of no sun in monsoon; must be measured, not assumed |

### 2.9 The flood extension (say one sentence, don't overreach)

The same node family, with a pressure transducer instead of a geophone, becomes a **river-level
node**: upstream level + rating curve + IMD/INCOIS forecast → flood **arrival time** for the village
downstream, on the same LoRa network and the same alarm. Landslides get seconds; floods get hours;
both get delivered by the same ₹6,000 node and the same certificate logic.

---

## Part 3 — Which one should the team build?

Not a hedge — an actual recommendation, with the reasoning visible:

| | **PRISM (current)** | **SIREN (this idea)** |
|---|---|---|
| Idea size | Large — reframes the SAR problem | Smaller, but deep |
| Physical risk in demo | Medium-high (60 GHz, 60 % success) | **Low (~90 %)** |
| Wins the "innovative" criterion | **Strongly** | Well, but less novel-sounding |
| Wins the "execution" criterion | If hardware cooperates | **Almost certainly** |
| Data feeds genuinely load-bearing | Yes (OSM→p₀, IMD→penalty) | Yes, and more centrally (thresholds) |
| Real-world evidence base | Strong (FINDER, USAR practice) | **Very strong** (published detectors, published thresholds) |
| Deployment realism for India | Building collapse: strong. Valley landslide: weak | **Strong for both, immediately** |

**My read:** PRISM is the better *thesis*; SIREN is the better *bet*. If the team wants the highest
chance of a demo that lands, and a solution that genuinely fits "Wayanad at 2 a.m." rather than
"a building collapse at noon", build SIREN and keep PRISM's fusion engine and certificate as the
shared backbone — the two are the same mathematics pointed at two hazards. That is also a much
stronger pitch line than either alone:

> **"One evidence engine, two clocks. PRISM finds the living. SIREN warns the sleeping."**
